(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["usersetup-usersetup-module"],{

/***/ "./src/app/shared/header-new/header-new.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/shared/header-new/header-new.component.ts ***!
  \***********************************************************/
/*! exports provided: HeaderNewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderNewComponent", function() { return HeaderNewComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



const _c0 = function () { return ["/dashboardnew"]; };
const _c1 = function () { return ["/login"]; };
class HeaderNewComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.user_name = localStorage.getItem("userName") ? (localStorage.getItem("userName").toUpperCase()) : "";
        this.role_name = localStorage.getItem("role_name") ? (localStorage.getItem("role_name").toUpperCase()) : "";
        // if ($(window).width() < 992) {
        //   //  alert('Less than 960');
        //  $('.sidebar').addClass('fliph');
        // }
        //  $(window).resize(function() {
        if ($(window).width() < 960) {
            $('.sidebar').addClass('fliph');
        }
        //  });
        $(window).resize(function () {
            if ($(window).width() < 960) {
                $('.sidebar').addClass('fliph');
            }
        });
    }
    btnnav() {
        $('.sidebar').toggleClass('fliph');
    }
    showChangePassword() {
        this.router.navigate(["/change-password"]);
    }
}
HeaderNewComponent.ɵfac = function HeaderNewComponent_Factory(t) { return new (t || HeaderNewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"])); };
HeaderNewComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HeaderNewComponent, selectors: [["app-header-new"]], decls: 31, vars: 7, consts: [[1, "header", "cstmshadow", "m-0", "megenta"], [1, "user-panel2", "pt-0", 3, "routerLink"], ["src", "../../assets/images/sbiyono.svg", 1, "img-fluid", "width85p", "pt-3"], [1, "navbar", "navbar-toggleable-md", "navbar-light", "pt-0", "pb-0"], ["id", "navbarNavDropdown", 1, "navbar-collapse", "flex-row-reverse", "mobdesign"], [1, "navbar-nav"], [1, "nav-item", "dropdown", "user-menu", "mobhide"], ["href", "javascript:void(0)", "id", "navbarDropdownMenuLink", "data-toggle", "dropdown", "aria-haspopup", "true", "aria-expanded", "false", 1, "nav-link", "cstmlink", "cstmpadding", "dropdown-toggle", "text-white"], [1, "hidden-xs"], [1, "m-0", "font8"], [1, "m-0", 2, "font-size", "1.2em"], [1, "nav-item", "dropdown", "user-menu", "border-noneleft"], [1, ""], [1, "m-0", "font7"], ["src", "../../assets/images/profile-user.svg", "alt", "User Image", 1, "user-image"], ["aria-labelledby", "navbarDropdownMenuLink", 1, "dropdown-menu"], ["href", "javascript:void(0)", 1, "dropdown-item"], ["href", "javascript:void(0)", 1, "dropdown-item", 3, "click"], ["href", "javascript:void(0)", 1, "dropdown-item", 3, "routerLink"]], template: function HeaderNewComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "nav", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ul", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "label", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Workbench Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "li", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](20, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "img", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "a", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "a", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HeaderNewComponent_Template_a_click_27_listener() { return ctx.showChangePassword(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Change Password");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "a", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Logout");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](5, _c0));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.role_name);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.user_name);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.role_name);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](6, _c1));
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLinkWithHref"]], styles: ["@media screen and (max-width:991px)\r\n{\r\n    \r\n    \r\n    .mobdesign[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%]\r\n    {\r\n        position: relative;\r\n    top: -10px;\r\n    right: 2px;\r\n    }\r\n\r\n    .header[_ngcontent-%COMP%]   .mobdesign[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\r\n        color: #fff;\r\n        padding: 10px 10px;\r\n        position: relative;\r\n    }\r\n    .mobdesign[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\r\n        background: #ddd;\r\n        text-decoration: none;\r\n    }\r\n    .cstmpadding[_ngcontent-%COMP%] {\r\n        padding: 10px 9px 10px 0px !important;\r\n    }\r\n    .hidden-xs[_ngcontent-%COMP%]\r\n    {\r\n        display: none;\r\n    }\r\n    .mmr[_ngcontent-%COMP%]\r\n    {\r\n        margin-right: 0px !important\r\n    }\r\n    \r\n    .cstmshadow[_ngcontent-%COMP%]   .navbar-toggleable-md[_ngcontent-%COMP%]\r\n    {\r\n        padding: 0px !important;\r\n    }\r\n    \r\n    .navbar-toggleable-md[_ngcontent-%COMP%]   .navbar-nav[_ngcontent-%COMP%] {\r\n        flex-direction: row;\r\n        float: right;\r\n    }\r\n.navbar-toggleable-md[_ngcontent-%COMP%] {\r\n    flex-direction: row;\r\n    flex-wrap: nowrap;\r\n    align-items: center;\r\n}\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hlYWRlci1uZXcvaGVhZGVyLW5ldy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztJQUVJOzs7Ozs7O09BT0c7SUFDSDs7O09BR0c7SUFDSDs7UUFFSSxrQkFBa0I7SUFDdEIsVUFBVTtJQUNWLFVBQVU7SUFDVjs7SUFFQTtRQUNJLFdBQVc7UUFDWCxrQkFBa0I7UUFDbEIsa0JBQWtCO0lBQ3RCO0lBQ0E7UUFDSSxnQkFBZ0I7UUFDaEIscUJBQXFCO0lBQ3pCO0lBQ0E7UUFDSSxxQ0FBcUM7SUFDekM7SUFDQTs7UUFFSSxhQUFhO0lBQ2pCO0lBQ0E7O1FBRUk7SUFDSjtJQUNBOztPQUVHO0lBQ0g7O1FBRUksdUJBQXVCO0lBQzNCOztJQUVBO1FBS0ksbUJBQW1CO1FBQ25CLFlBQVk7SUFDaEI7QUFDSjtJQUtJLG1CQUFtQjtJQUduQixpQkFBaUI7SUFJakIsbUJBQW1CO0FBQ3ZCO0FBQ0EiLCJmaWxlIjoic3JjL2FwcC9zaGFyZWQvaGVhZGVyLW5ldy9oZWFkZXItbmV3LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjk5MXB4KVxyXG57XHJcbiAgICAvKiAubW9iZGVzaWduXHJcbiAgICB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZGRkO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA0NXB4O1xyXG4gICAgei1pbmRleDogOTtcclxuICAgIH0gKi9cclxuICAgIC8qIC5zaWRlYmFyXHJcbiAgICB7XHJcbiAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICB9ICovXHJcbiAgICAubW9iZGVzaWduIHVsIGxpIGEgLmxhYmVsXHJcbiAgICB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtMTBweDtcclxuICAgIHJpZ2h0OiAycHg7XHJcbiAgICB9XHJcblxyXG4gICAgLmhlYWRlciAubW9iZGVzaWduIC5uYXZiYXItbmF2IC5uYXYtbGluayB7XHJcbiAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgcGFkZGluZzogMTBweCAxMHB4O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIH1cclxuICAgIC5tb2JkZXNpZ24gdWwgbGkgYTpob3ZlciB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2RkZDtcclxuICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICB9XHJcbiAgICAuY3N0bXBhZGRpbmcge1xyXG4gICAgICAgIHBhZGRpbmc6IDEwcHggOXB4IDEwcHggMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAuaGlkZGVuLXhzXHJcbiAgICB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxuICAgIC5tbXJcclxuICAgIHtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDBweCAhaW1wb3J0YW50XHJcbiAgICB9XHJcbiAgICAvKiAubW9iZGVzaWduIHVsIGxpIGEge1xyXG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjYjViNWI1O1xyXG4gICAgfSAqL1xyXG4gICAgLmNzdG1zaGFkb3cgLm5hdmJhci10b2dnbGVhYmxlLW1kXHJcbiAgICB7XHJcbiAgICAgICAgcGFkZGluZzogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIC5uYXZiYXItdG9nZ2xlYWJsZS1tZCAubmF2YmFyLW5hdiB7XHJcbiAgICAgICAgLXdlYmtpdC1ib3gtb3JpZW50OiBob3Jpem9udGFsO1xyXG4gICAgICAgIC13ZWJraXQtYm94LWRpcmVjdGlvbjogbm9ybWFsO1xyXG4gICAgICAgIC13ZWJraXQtZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAgICAtbXMtZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgIH1cclxuLm5hdmJhci10b2dnbGVhYmxlLW1kIHtcclxuICAgIC13ZWJraXQtYm94LW9yaWVudDogaG9yaXpvbnRhbDtcclxuICAgIC13ZWJraXQtYm94LWRpcmVjdGlvbjogbm9ybWFsO1xyXG4gICAgLXdlYmtpdC1mbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgLW1zLWZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgLXdlYmtpdC1mbGV4LXdyYXA6IG5vd3JhcDtcclxuICAgIC1tcy1mbGV4LXdyYXA6IG5vd3JhcDtcclxuICAgIGZsZXgtd3JhcDogbm93cmFwO1xyXG4gICAgLXdlYmtpdC1ib3gtYWxpZ246IGNlbnRlcjtcclxuICAgIC13ZWJraXQtYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbn1cclxuXHJcbiJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HeaderNewComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-header-new',
                templateUrl: './header-new.component.html',
                styleUrls: ['./header-new.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/assign-menu-role/assign-menu-role.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/usersetup/assign-menu-role/assign-menu-role.component.ts ***!
  \**************************************************************************/
/*! exports provided: AssignMenuRoleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AssignMenuRoleComponent", function() { return AssignMenuRoleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");




class AssignMenuRoleComponent {
    constructor() { }
    ngOnInit() {
    }
}
AssignMenuRoleComponent.ɵfac = function AssignMenuRoleComponent_Factory(t) { return new (t || AssignMenuRoleComponent)(); };
AssignMenuRoleComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AssignMenuRoleComponent, selectors: [["app-assign-menu-role"]], decls: 66, vars: 0, consts: [[1, "container-fluid", "pt-2"], [1, "col-sm-12", "p-0"], [1, "row"], [1, "col-sm-12"], [1, "font600", "mt-2", "tabsty", "bg_border", "pull-left"], [1, "card", "remove-shadow", "mb-1"], [1, "card-header", "font8"], [1, "card-body", "p-0", "mt-2"], [1, "row", "m-2"], [1, "col-sm-1"], [1, "col-sm-3"], [1, "form-control"], [1, "col-sm-4"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-save"], ["href", "javascript:void(0)", 1, "btn", "btn-outline-dark", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-refresh"], [1, "card-body", "nopadding"], [1, "col-sm-12", "nopadding"], [1, "table", "table-bordered", "cstmtbl", "mb-0"], [1, "text-center"], ["href", "javascript:void(0)", 1, "btn-dark", "btn", "btn-sm", "mr-2"], [1, "fa", "fa-edit"], ["href", "javascript:void(0)", 1, "btn", "btn-white-dark", "btn", "btn-sm"], [1, "fa", "fa-eye"]], template: function AssignMenuRoleComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-new");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Assign Module To Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Asign Role Detail");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "--Select--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Module");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "--Select--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "a", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](29, "i", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, " Update ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "a", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " Reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Rolewise Module List");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "table", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "th", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, " Sr No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, "Module");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "Created Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "th", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "Action");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "td", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, " 1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, " HR Admin ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](58, "deo-pi12");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, "04/20/2021");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "td", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "a", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](63, "i", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "a", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](65, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__["HeaderNewComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"]], styles: [".cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    background: #f5f5f5;\r\n    font-size: .8rem;\r\n}\r\n.cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    \r\n    font-size: .8rem;\r\n}\r\n.font8[_ngcontent-%COMP%] \r\n{\r\n    font-size: .8rem;\r\n}\r\n.mttop-3[_ngcontent-%COMP%]\r\n{\r\n    margin-top: -3px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnNldHVwL2Fzc2lnbi1tZW51LXJvbGUvYXNzaWduLW1lbnUtcm9sZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQixnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLHdCQUF3QjtJQUN4Qix5QkFBeUI7SUFDekIsZ0JBQWdCO0FBQ3BCO0FBQ0E7O0lBRUksZ0JBQWdCO0FBQ3BCO0FBQ0E7O0lBRUksZ0JBQWdCO0FBQ3BCIiwiZmlsZSI6InNyYy9hcHAvdXNlcnNldHVwL2Fzc2lnbi1tZW51LXJvbGUvYXNzaWduLW1lbnUtcm9sZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNzdG10YmwgdHIgdGgge1xyXG4gICAgcGFkZGluZzogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcclxuICAgIGZvbnQtc2l6ZTogLjhyZW07XHJcbn1cclxuLmNzdG10YmwgdHIgdGQge1xyXG4gICAgcGFkZGluZzogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgLyogYmFja2dyb3VuZDogI2Y1ZjVmNTsgKi9cclxuICAgIGZvbnQtc2l6ZTogLjhyZW07XHJcbn1cclxuLmZvbnQ4IFxyXG57XHJcbiAgICBmb250LXNpemU6IC44cmVtO1xyXG59XHJcbi5tdHRvcC0zXHJcbntcclxuICAgIG1hcmdpbi10b3A6IC0zcHg7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AssignMenuRoleComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-assign-menu-role',
                templateUrl: './assign-menu-role.component.html',
                styleUrls: ['./assign-menu-role.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/manage-menu/manage-menu.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/usersetup/manage-menu/manage-menu.component.ts ***!
  \****************************************************************/
/*! exports provided: ManageMenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageMenuComponent", function() { return ManageMenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");



class ManageMenuComponent {
    constructor() { }
    ngOnInit() {
    }
}
ManageMenuComponent.ɵfac = function ManageMenuComponent_Factory(t) { return new (t || ManageMenuComponent)(); };
ManageMenuComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ManageMenuComponent, selectors: [["app-manage-menu"]], decls: 73, vars: 0, consts: [[1, "container-fluid", "pt-2"], [1, "col-sm-12", "p-0", "my-2"], [1, "row"], [1, "col-sm-3"], [1, "card"], [1, "card-header", "font8", "bg-white"], [1, "card-body", "min-hyt80"], [1, "col-sm-9"], [1, "row", "m-2"], [1, "col-sm-12", "text-center"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm", "rounded-pill", "px-3", "mr-2"], ["href", "javascript:void(0)", 1, "btn", "btn-outline-dark", "btn-white-dark", "btn-sm", "rounded-pill", "px-3", "mr-2"], [1, "col-sm-12", "p-0"], [1, "card", "shadow-none"], [1, "card-body", "py-3", "px-0"], [1, "col-sm-2"], [1, "col-sm-4"], ["type", "text", "placeholder", "Resource (En)", 1, "form-control"], ["type", "text", "placeholder", "Resource (Hn)", 1, "form-control"], ["type", "text", "placeholder", "Resource URL ", 1, "form-control"], ["type", "text", "placeholder", "Description", 1, "form-control"], ["type", "text", "placeholder", "Display Order", 1, "form-control"], ["type", "text", "placeholder", "Parent Resource", "disabled", "", 1, "form-control"], ["type", "checkbox", 1, "mmtop-5"], [1, "row", "my-3"], [1, "fa", "fa-save"], [1, "fa", "fa-refresh"]], template: function ManageMenuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-new");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Resource List");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Add Resource");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, " New Resource ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "a", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, " Delete Resource ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](29, "Resource (En)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](31, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Resource (Hn)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Resource URL ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](42, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](47, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "Display Order ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "Parent Resource");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, "Is Visiable");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](64, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](68, "i", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](69, " Save Resource ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "a", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](71, "i", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](72, " Reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__["HeaderNewComponent"]], styles: [".font8[_ngcontent-%COMP%]\r\n{\r\n    font-size: 0.8rem;\r\n}\r\n.mmtop-3[_ngcontent-%COMP%]\r\n{\r\n    margin-top: 5px;\r\n}\r\n.min-hyt80[_ngcontent-%COMP%]\r\n{\r\n    min-height: 80vh;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnNldHVwL21hbmFnZS1tZW51L21hbmFnZS1tZW51LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0lBRUksaUJBQWlCO0FBQ3JCO0FBQ0E7O0lBRUksZUFBZTtBQUNuQjtBQUNBOztJQUVJLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJzcmMvYXBwL3VzZXJzZXR1cC9tYW5hZ2UtbWVudS9tYW5hZ2UtbWVudS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvbnQ4XHJcbntcclxuICAgIGZvbnQtc2l6ZTogMC44cmVtO1xyXG59XHJcbi5tbXRvcC0zXHJcbntcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxufVxyXG4ubWluLWh5dDgwXHJcbntcclxuICAgIG1pbi1oZWlnaHQ6IDgwdmg7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ManageMenuComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-manage-menu',
                templateUrl: './manage-menu.component.html',
                styleUrls: ['./manage-menu.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/manage-resource/manage-resource.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/usersetup/manage-resource/manage-resource.component.ts ***!
  \************************************************************************/
/*! exports provided: ManageResourceComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageResourceComponent", function() { return ManageResourceComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");




class ManageResourceComponent {
    constructor() { }
    ngOnInit() {
        $("#hidemodule").hide();
        $("#addmoduledetail").hide();
    }
    addmodule() {
        $("#hidemodule").show();
        $("#addmoduledetail").hide();
    }
    closemodule() {
        $("#hidemodule").hide();
        $("#addmoduledetail").hide();
    }
    hideresource() {
        $("#hidemodule").hide();
        $("#addmoduledetail").hide();
    }
    addresource() {
        $("#addmoduledetail").show();
        $("#hidemodule").hide();
    }
}
ManageResourceComponent.ɵfac = function ManageResourceComponent_Factory(t) { return new (t || ManageResourceComponent)(); };
ManageResourceComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ManageResourceComponent, selectors: [["app-manage-resource"]], decls: 149, vars: 0, consts: [[1, "container-fluid", "pt-2"], [1, "col-sm-12", "p-0"], [1, "row"], [1, "col-sm-12"], [1, "font600", "mt-2", "tabsty", "bg_border", "pull-left"], [1, "example-header", "cstmpage", "pt-0", "cstmflxs", "pull-left", "mt-2"], [1, "mr-1"], ["id", "page-size", 1, "cstmselect"], ["value", "10", "selected", ""], ["value", "100"], ["value", "500"], ["value", "1000"], ["href", "javascript:void(0)", 1, "btn", "btn-sm", "btn-white-dark", "filtericon", "pt-0", "pb-0", "hyt24", "mttop-3"], [1, "fa", "fa-filter"], ["href", "javascript:void(0)", 1, "btn", "pull-right", "mt-2", "btn-dark", "rounded-pill", "px-3", "btn-sm", 3, "click"], [1, "mt-0", "mb-0"], [1, "card", "remove-shadow", "mb-1"], [1, "card-header", "font8", "py-2"], [1, "card-body", "nopadding"], [1, "col-sm-12", "nopadding"], [1, "table", "table-bordered", "cstmtbl", "mb-0"], [1, "text-center", "wid10"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm", "mr-2", "font8"], [1, "fa", "fa-edit"], ["href", "javascript:void(0)", 1, "btn", "btn-white-dark", "btn-sm", "mr-2", "font8", 3, "click"], [1, "fa", "fa-plus"], ["id", "hidemodule", 1, "card", "remove-shadow", "mb-1"], [1, "card-header", "font8"], [1, "card-body", "p-0", "mt-2"], [1, "row", "m-2"], [1, "col-sm-2"], [1, "col-sm-3"], ["type", "text", "placeholder", "Module Name (In Eng.)", 1, "form-control"], [1, "col-sm-2", "mobilenone"], ["type", "text", "placeholder", "Module Name (In Hin.)", 1, "form-control"], [1, "col-sm-1"], ["type", "checkbox", 1, "mt-1"], [1, "row", "my-3"], [1, "col-sm-12", "text-center"], ["href", "javascript:void(0)", 1, "font8", "btn", "btn-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-save"], ["href", "javascript:void(0)", 1, "font8", "btn", "btn-outline-dark", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-refresh"], ["href", "javascript:void(0)", 1, "font8", "btn", "btn-outline-dark", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2", 3, "click"], [1, "fa", "fa-times"], ["id", "addmoduledetail", 1, "card", "remove-shadow"], [1, "font8", "font600", "px-2", "pt-2"], [1, "text-danger", "mr-2"], [1, "col-sm-12", "alert", "alert-white", "mb-0"], [1, "ml-2"], [1, "col-sm-12", "alert", "alert-dark-light", "mb-0"], ["href", "javascript:void(0)", 1, "font8", "btn", "btn-dark", "btn-sm", "rounded-pill", "px-3", "mr-2"], ["href", "javascript:void(0)", 1, "font8", "btn-outline-dark", "btn-sm", "btn-white-dark", "btn", "rounded-pill", "px-3", "mr-2", 3, "click"]], template: function ManageResourceComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-new");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Module");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Page Size:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "select", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "10");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "50");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "option", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "100");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "500");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "option", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "1000");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "\u00A0\u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "a", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "a", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageResourceComponent_Template_a_click_24_listener() { return ctx.addmodule(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, " Add New Module ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "hr", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Module List");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "table", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, " Sr No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Module Name (In Eng.)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Module Name (In Hin.)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Resources Name(s)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](44, "Action");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "td", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](47, " 1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "On Behalf Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "On Behalf Services");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, "Masters,Manage Employee");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "td", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "a", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](56, "i", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "a", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageResourceComponent_Template_a_click_57_listener() { return ctx.addresource(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "i", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, "Add Module");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](67, "Module Name (In Eng.)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](69, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](72, "Module Name (In Hin.)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "input", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](77, "Is Active");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](79, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "a", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](83, "i", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](84, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "a", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](86, "i", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](87, " Reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "a", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageResourceComponent_Template_a_click_88_listener() { return ctx.closemodule(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](89, "i", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](90, " Close Module ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "div", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "h6", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](93, " ALL RESOURCE \u00A0\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](94, "span", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](95, "CURRENT SELECTED MODULE :");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](97, "ON BEHALF SERVICES");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](100, "Resource Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](105, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](107, " Allowance & Other Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](110, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112, " Arrears");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](115, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](117, " Court Module");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](119, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](120, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](122, " Establishment");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](123, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](125, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](127, " Manage Employee");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](130, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](131, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](132, " Matser");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](135, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](137, " Payroll");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](138, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "div", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](140, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](142, " Sub Report (child)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](144, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "a", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](146, " Assign Resourceto Module ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "a", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageResourceComponent_Template_a_click_147_listener() { return ctx.hideresource(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](148, " Close ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__["HeaderNewComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"]], styles: [".cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    background: #f5f5f5;\r\n    font-size: .8rem;\r\n}\r\n.cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    \r\n    font-size: .8rem;\r\n}\r\n.font8[_ngcontent-%COMP%] \r\n{\r\n    font-size: .8rem;\r\n}\r\n.wid10[_ngcontent-%COMP%]\r\n{\r\n    width: 10%;\r\n}\r\n.mttop-3[_ngcontent-%COMP%]\r\n{\r\n    margin-top: -3px;\r\n}\r\n@media screen and (max-width:991px)\r\n{\r\n    .mobilenone[_ngcontent-%COMP%]\r\n    {\r\n        display: none;\r\n    }\r\n}\r\n.alert-white[_ngcontent-%COMP%], .alert-dark-light[_ngcontent-%COMP%]\r\n{\r\n    padding: 6px 10px !important;\r\n    font-weight: 600 !important;\r\n}\r\n.alert-dark-light[_ngcontent-%COMP%]\r\n{\r\n    background: #f8f8f8;\r\n    border:1px solid #f8f8f8;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnNldHVwL21hbmFnZS1yZXNvdXJjZS9tYW5hZ2UtcmVzb3VyY2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSx3QkFBd0I7SUFDeEIseUJBQXlCO0lBQ3pCLGdCQUFnQjtBQUNwQjtBQUNBOztJQUVJLGdCQUFnQjtBQUNwQjtBQUNBOztJQUVJLFVBQVU7QUFDZDtBQUNBOztJQUVJLGdCQUFnQjtBQUNwQjtBQUNBOztJQUVJOztRQUVJLGFBQWE7SUFDakI7QUFDSjtBQUNBOztJQUVJLDRCQUE0QjtJQUM1QiwyQkFBMkI7QUFDL0I7QUFDQTs7SUFFSSxtQkFBbUI7SUFDbkIsd0JBQXdCO0FBQzVCIiwiZmlsZSI6InNyYy9hcHAvdXNlcnNldHVwL21hbmFnZS1yZXNvdXJjZS9tYW5hZ2UtcmVzb3VyY2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jc3RtdGJsIHRyIHRoIHtcclxuICAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6ICNmNWY1ZjU7XHJcbiAgICBmb250LXNpemU6IC44cmVtO1xyXG59XHJcbi5jc3RtdGJsIHRyIHRkIHtcclxuICAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcclxuICAgIC8qIGJhY2tncm91bmQ6ICNmNWY1ZjU7ICovXHJcbiAgICBmb250LXNpemU6IC44cmVtO1xyXG59XHJcbi5mb250OCBcclxue1xyXG4gICAgZm9udC1zaXplOiAuOHJlbTtcclxufVxyXG4ud2lkMTBcclxue1xyXG4gICAgd2lkdGg6IDEwJTtcclxufVxyXG4ubXR0b3AtM1xyXG57XHJcbiAgICBtYXJnaW4tdG9wOiAtM3B4O1xyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6OTkxcHgpXHJcbntcclxuICAgIC5tb2JpbGVub25lXHJcbiAgICB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxufVxyXG4uYWxlcnQtd2hpdGUsLmFsZXJ0LWRhcmstbGlnaHRcclxue1xyXG4gICAgcGFkZGluZzogNnB4IDEwcHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDAgIWltcG9ydGFudDtcclxufVxyXG4uYWxlcnQtZGFyay1saWdodFxyXG57XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjhmOGY4O1xyXG4gICAgYm9yZGVyOjFweCBzb2xpZCAjZjhmOGY4O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ManageResourceComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-manage-resource',
                templateUrl: './manage-resource.component.html',
                styleUrls: ['./manage-resource.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/manage-role/manage-role.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/usersetup/manage-role/manage-role.component.ts ***!
  \****************************************************************/
/*! exports provided: ManageRoleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageRoleComponent", function() { return ManageRoleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _models_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../_models/page */ "./src/app/_models/page.ts");
/* harmony import */ var _services_form_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../_services/form.service */ "./src/app/_services/form.service.ts");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/__ivy_ngcc__/fesm2015/swimlane-ngx-datatable.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");








function ManageRoleComponent_ngx_datatable_column_29_ng_template_1_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const value_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().value;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", value_r8, " ");
} }
function ManageRoleComponent_ngx_datatable_column_29_ng_template_1_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageRoleComponent_ngx_datatable_column_29_ng_template_1_div_1_Template_a_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14); const row_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().row; const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r12.onEdit(row_r7); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "i", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "\u00A0\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function ManageRoleComponent_ngx_datatable_column_29_ng_template_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, ManageRoleComponent_ngx_datatable_column_29_ng_template_1_div_0_Template, 2, 1, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ManageRoleComponent_ngx_datatable_column_29_ng_template_1_div_1_Template, 4, 0, "div", 39);
} if (rf & 2) {
    const lst_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", lst_r4.headerName != "Action");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", lst_r4.headerName == "Action");
} }
function ManageRoleComponent_ngx_datatable_column_29_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ngx-datatable-column", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ManageRoleComponent_ngx_datatable_column_29_ng_template_1_Template, 2, 2, "ng-template", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const lst_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("name", lst_r4.headerName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("prop", lst_r4.field);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("sortable", lst_r4.sortable)("width", lst_r4.width);
} }
function ManageRoleComponent_ng_template_31_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " | Page Size:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function ManageRoleComponent_ng_template_31_select_3_option_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "option", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const size_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", size_r24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", size_r24, "");
} }
function ManageRoleComponent_ng_template_31_select_3_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "select", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function ManageRoleComponent_ng_template_31_select_3_Template_select_ngModelChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r26); const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r25.page.size = $event; })("ngModelChange", function ManageRoleComponent_ng_template_31_select_3_Template_select_ngModelChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r26); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r27.onPageSizeChange($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ManageRoleComponent_ng_template_31_select_3_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r22.page.size);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r22.sizeList);
} }
function ManageRoleComponent_ng_template_31_Template(rf, ctx) { if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ManageRoleComponent_ng_template_31_span_1_Template, 2, 0, "span", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, ManageRoleComponent_ng_template_31_select_3_Template, 2, 2, "select", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "datatable-pager", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function ManageRoleComponent_ng_template_31_Template_datatable_pager_change_6_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r29); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r28.onFooterPage($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rowCount_r16 = ctx.rowCount;
    const selectedCount_r18 = ctx.selectedCount;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" Total Results: ", rowCount_r16, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", rowCount_r16 != 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", rowCount_r16 != 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("hidden", selectedCount_r18 <= 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" | Selected: ", selectedCount_r18, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("pagerLeftArrowIcon", "datatable-icon-left")("pagerRightArrowIcon", "datatable-icon-right")("pagerPreviousIcon", "datatable-icon-prev")("pagerNextIcon", "datatable-icon-skip")("page", ctx_r1.page.pageNumber)("size", ctx_r1.page.size)("count", ctx_r1.page.totalElements)("hidden", !(ctx_r1.page.totalElements / ctx_r1.page.size > 1));
} }
function ManageRoleComponent_a_53_Template(rf, ctx) { if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageRoleComponent_a_53_Template_a_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r31); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r30.saveRole(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function ManageRoleComponent_a_54_Template(rf, ctx) { if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageRoleComponent_a_54_Template_a_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r33); const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r32.saveRole(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "i", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, " Update ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class ManageRoleComponent {
    constructor(formService) {
        this.formService = formService;
        this.roleName = "";
        this.isactive = true;
        this.columnDefs = [];
        this.rowData = [];
        this.lookupArr = [];
        // for ngx grid
        this.gridType = "ngx";
        this.pagesize = "10";
        this.page = new _models_page__WEBPACK_IMPORTED_MODULE_1__["Page"]();
        this.sizeList = [];
        this.data = [];
        this.editRoleId = "0";
    }
    ngOnInit() {
        $("#hiderole").hide();
        this.rowLimit = 10;
        this.page.size = 10;
        this.page.totalElements = 0;
        this.sizeList = this.page.sizeList;
        this.columnDefs = [];
        this.columnDefs.push({ field: "role_name", headerName: "Role Name", sortable: true, wrapText: true, autoHeight: true });
        this.columnDefs.push({ field: "isactive", headerName: "Active", sortable: true, wrapText: true, autoHeight: true });
        this.lookupArr.push({ "index": 1, "view_type": 1, "columnname": "role_name", "type": "1", "control_type": 1 });
        this.lookupArr.push({ "index": 2, "view_type": 1, "columnname": "isactive", "type": "1", "control_type": 6 });
        this.setPage(this.page);
        this.columnDefs.push({
            headerName: 'Action',
            pinned: 'right',
            field: "val",
            cellRenderer: 'buttonRenderer',
            cellRendererParams: {
                actionList: [
                    { label: "Edit", for: "view", form_status: 1, db_status: 1, str: "edit", onClick: this.onEdit.bind(this) },
                ]
            },
            width: 120,
            resizable: true
        });
    }
    bindNgxDataGrid(pageInfo, status) {
        // console.log(JSON.stringify(pageInfo))
        let total, pagesize, limit, offset = 0;
        pagesize = pageInfo.size;
        if (pageInfo.pageNumber == 0 || pageInfo.pageNumber == 1 || status == 0) {
            offset = 0;
        }
        else {
            offset = ((pageInfo.pageNumber - 1) * pagesize);
        }
        this.data = [];
        this.formService.getNgxGridData(this.lookupArr, "app_tblrole", "role_id", "", "", pagesize, offset, '', '').subscribe(res => {
            // console.log("this.page==>",res[1].rows)    
            this.page.totalElements = res[0].rows[0]["total"];
            this.rowCount = res[0].rows[0]["total"];
            this.data = res[1].rows;
            // console.log("==>",res[0].rows)    
        });
    }
    setPage(pageInfo) {
        this.page.pageNumber = pageInfo.offset;
        this.bindNgxDataGrid(this.page, 1);
    }
    onPageSizeChange(pageInfo) {
        this.page.size = +pageInfo;
        this.setPage({ offset: this.page.pageNumber });
    }
    onFooterPage(event) {
        let offset = (event.page);
        this.setPage({ offset: offset });
    }
    addrole() {
        $("#hiderole").show();
    }
    closerole() {
        $("#hiderole").hide();
    }
    saveRole() {
        if (this.roleName == "" || this.roleName == undefined || this.roleName == null) {
            alert("Role is required.");
            return false;
        }
        else {
            let insertQry = "", msg = "";
            if (this.editRoleId == "0") {
                msg = "Save Successfully";
                insertQry = "insert into app_tblrole(role_name,isactive,createdby) values('" + this.roleName + "'," + this.isactive + ",1)";
            }
            else {
                msg = "Update Successfully";
                insertQry = "update app_tblrole set role_name='" + this.roleName + "', isactive=" + this.isactive + " where role_id=" + this.editRoleId;
            }
            this.formService.getFormData(insertQry).subscribe(res => {
                alert(msg);
                this.reset(1);
            });
        }
        // console.log(this.roleName)
        // console.log(this.isactive)
    }
    onEdit(e) {
        this.addrole();
        this.editRoleId = e["role_id"];
        this.roleName = e["role_name"];
        this.isactive = e["isactive"];
    }
    reset(status) {
        this.editRoleId = "0";
        this.roleName = "";
        if (status == 1) {
            this.rowLimit = 10;
            this.page.size = 10;
            this.page.totalElements = 0;
            this.setPage(this.page);
        }
    }
}
ManageRoleComponent.ɵfac = function ManageRoleComponent_Factory(t) { return new (t || ManageRoleComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_form_service__WEBPACK_IMPORTED_MODULE_2__["FormService"])); };
ManageRoleComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ManageRoleComponent, selectors: [["app-manage-role"]], decls: 61, vars: 13, consts: [[1, "container-fluid", "mb-2"], [1, "col-sm-12", "p-0"], [1, "row"], [1, "col-sm-12"], [1, "font600", "mt-2", "tabsty", "bg_border", "pull-left"], [1, "example-header", "cstmpage", "pt-0", "cstmflxs", "pull-left", "mt-2"], [1, "mr-1"], ["id", "page-size", 1, "cstmselect"], ["value", "10", "selected", ""], ["value", "100"], ["value", "500"], ["value", "1000"], ["href", "javascript:void(0)", 1, "btn", "btn-sm", "btn-white-dark", "filtericon", "pt-0", "pb-0", "hyt24", "mttop-3"], [1, "fa", "fa-filter"], ["href", "javascript:void(0)", 1, "btn", "pull-right", "mt-2", "btn-dark", "rounded-pill", "px-3", "btn-sm", 3, "click"], [1, "mt-0", "mb-0"], [1, "card", "border-top-0", "border-bottom-0"], ["rowHeight", "auto", 1, "material", 3, "rows", "columnMode", "headerHeight", "footerHeight", "externalPaging", "count", "offset", "limit", "page"], [3, "sortable", "name", "prop", "width", 4, "ngFor", "ngForOf"], ["ngx-datatable-footer-template", ""], ["id", "hiderole", 1, "card", "mb-1"], [1, "card-header", "font8"], [1, "card-body", "p-0", "mt-2"], [1, "row", "m-2"], [1, "col-sm-2"], [1, "col-sm-4"], ["type", "text", "placeholder", "Role Name", "id", "roleName", "name", "roleName", 1, "form-control", 3, "ngModel", "ngModelChange"], [1, "col-sm-1", "mobilenone"], [1, "col-sm-1"], ["type", "checkbox", "id", "isactive", "name", "isactive", 1, "mt-1", 3, "ngModel", "ngModelChange"], [1, "row", "my-3"], [1, "col-sm-12", "text-center"], ["href", "javascript:void(0)", "class", "btn btn-dark btn-sm px-3 rounded-pill mr-2", 3, "click", 4, "ngIf"], ["href", "javascript:void(0)", "class", "btn btn-dark px-3 btn-sm rounded-pill mr-2", 3, "click", 4, "ngIf"], ["href", "javascript:void(0)", 1, "btn", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2", 3, "click"], [1, "fa", "fa-refresh"], [1, "fa", "fa-times"], [3, "sortable", "name", "prop", "width"], ["ngx-datatable-cell-template", ""], [4, "ngIf"], ["title", "Action", "href", "javascript:void(0)", 1, "text-body", 3, "click"], [1, "fa", "fa-edit"], ["class", "mx-2", 4, "ngIf"], ["style", "padding: 2px 4px", "type", "text", 3, "ngModel", "ngModelChange", 4, "ngIf"], [3, "hidden"], [3, "pagerLeftArrowIcon", "pagerRightArrowIcon", "pagerPreviousIcon", "pagerNextIcon", "page", "size", "count", "hidden", "change"], [1, "mx-2"], ["type", "text", 2, "padding", "2px 4px", 3, "ngModel", "ngModelChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm", "px-3", "rounded-pill", "mr-2", 3, "click"], [1, "fa", "fa-save"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "px-3", "btn-sm", "rounded-pill", "mr-2", 3, "click"]], template: function ManageRoleComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-new");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Manage Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Page Size:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "select", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "10");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "50");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "option", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "100");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "500");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "option", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "1000");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "\u00A0\u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "a", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "a", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageRoleComponent_Template_a_click_24_listener() { return ctx.addrole(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, " Add New Role ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "hr", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "ngx-datatable", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("page", function ManageRoleComponent_Template_ngx_datatable_page_28_listener($event) { return ctx.setPage($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](29, ManageRoleComponent_ngx_datatable_column_29_Template, 2, 4, "ngx-datatable-column", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "ngx-datatable-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](31, ManageRoleComponent_ng_template_31_Template, 7, 13, "ng-template", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Role Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Role Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "input", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function ManageRoleComponent_Template_input_ngModelChange_42_listener($event) { return ctx.roleName = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "\u00A0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, "Is Active");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "input", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function ManageRoleComponent_Template_input_ngModelChange_50_listener($event) { return ctx.isactive = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](53, ManageRoleComponent_a_53_Template, 3, 0, "a", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](54, ManageRoleComponent_a_54_Template, 3, 0, "a", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "a", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageRoleComponent_Template_a_click_55_listener() { return ctx.reset(0); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](56, "i", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, " Reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "a", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageRoleComponent_Template_a_click_58_listener() { return ctx.closerole(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](59, "i", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, " Close Role Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("rows", ctx.data)("columnMode", "force")("headerHeight", 48)("footerHeight", 60)("externalPaging", true)("count", ctx.page.totalElements)("offset", ctx.page.pageNumber)("limit", ctx.page.size);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.columnDefs);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.roleName);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.isactive);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editRoleId == "0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.editRoleId != "0");
    } }, directives: [_shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_3__["HeaderNewComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_forms_forms_x"], _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["DatatableComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgForOf"], _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["DatatableFooterDirective"], _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["DataTableFooterTemplateDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["CheckboxControlValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["DataTableColumnDirective"], _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["DataTableColumnCellDirective"], _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_5__["DataTablePagerComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["SelectControlValueAccessor"]], styles: [".ngx-datatable {\n  display: block;\n  overflow: hidden;\n  justify-content: center;\n  position: relative;\n  -webkit-transform: translate3d(0, 0, 0);\n  /**\n   * Vertical Scrolling Adjustments\n   */\n  /**\n   * Horizontal Scrolling Adjustments\n   */\n  /**\n   * Fixed Header Height Adjustments\n   */\n  /**\n   * Fixed row height adjustments\n   */\n  /**\n   * Shared Styles\n   */\n  /**\n   * Header Styles\n   */\n  /**\n   * Body Styles\n   */\n  /**\n   * Footer Styles\n   */\n}\n.ngx-datatable [hidden] {\n  display: none !important;\n}\n.ngx-datatable *, .ngx-datatable *:before, .ngx-datatable *:after {\n  box-sizing: border-box;\n}\n.ngx-datatable.scroll-vertical .datatable-body {\n  overflow-y: auto;\n}\n.ngx-datatable.scroll-vertical .datatable-body .datatable-row-wrapper {\n  position: absolute;\n}\n.ngx-datatable.scroll-horz .datatable-body {\n  -webkit-overflow-scrolling: touch;\n}\n.ngx-datatable.fixed-header .datatable-header .datatable-header-inner {\n  white-space: nowrap;\n}\n.ngx-datatable.fixed-header .datatable-header .datatable-header-inner .datatable-header-cell {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.ngx-datatable.fixed-row .datatable-scroll {\n  white-space: nowrap;\n}\n.ngx-datatable.fixed-row .datatable-scroll .datatable-body-row {\n  white-space: nowrap;\n}\n.ngx-datatable.fixed-row .datatable-scroll .datatable-body-row .datatable-body-cell {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n  word-break: break-all !important;\n}\n.ngx-datatable.fixed-row .datatable-scroll .datatable-body-row .datatable-body-group-cell {\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.ngx-datatable .datatable-body-row,\n.ngx-datatable .datatable-row-center,\n.ngx-datatable .datatable-header-inner {\n  display: flex;\n  flex-direction: row;\n  -o-flex-flow: row;\n  flex-flow: row;\n}\n.ngx-datatable .datatable-body-cell,\n.ngx-datatable .datatable-header-cell {\n  overflow-x: hidden;\n  vertical-align: top;\n  display: inline-block;\n  line-height: 1.625;\n  word-break: break-all !important;\n}\n.ngx-datatable .datatable-body-cell:focus,\n.ngx-datatable .datatable-header-cell:focus {\n  outline: none;\n}\n.ngx-datatable .datatable-row-left,\n.ngx-datatable .datatable-row-right {\n  z-index: 9;\n}\n.ngx-datatable .datatable-row-left,\n.ngx-datatable .datatable-row-center,\n.ngx-datatable .datatable-row-group,\n.ngx-datatable .datatable-row-right {\n  position: relative;\n}\n.ngx-datatable .datatable-header {\n  display: block;\n  overflow: hidden;\n}\n.ngx-datatable .datatable-header .datatable-header-inner {\n  align-items: stretch;\n  -webkit-align-items: stretch;\n}\n.ngx-datatable .datatable-header .datatable-header-cell {\n  position: relative;\n  display: inline-block;\n}\n.ngx-datatable .datatable-header .datatable-header-cell.sortable .datatable-header-cell-wrapper {\n  cursor: pointer;\n}\n.ngx-datatable .datatable-header .datatable-header-cell.longpress .datatable-header-cell-wrapper {\n  cursor: move;\n}\n.ngx-datatable .datatable-header .datatable-header-cell .sort-btn {\n  line-height: 100%;\n  vertical-align: middle;\n  display: inline-block;\n  cursor: pointer;\n}\n.ngx-datatable .datatable-header .datatable-header-cell .resize-handle, .ngx-datatable .datatable-header .datatable-header-cell .resize-handle--not-resizable {\n  display: inline-block;\n  position: absolute;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  width: 5px;\n  padding: 0 4px;\n  visibility: hidden;\n}\n.ngx-datatable .datatable-header .datatable-header-cell .resize-handle {\n  cursor: ew-resize;\n}\n.ngx-datatable .datatable-header .datatable-header-cell.resizeable:hover .resize-handle {\n  visibility: visible;\n}\n.ngx-datatable .datatable-header .datatable-header-cell:hover .resize-handle--not-resizable {\n  visibility: visible;\n}\n.ngx-datatable .datatable-body {\n  position: relative;\n  z-index: 10;\n  display: block;\n}\n.ngx-datatable .datatable-body .datatable-scroll {\n  display: inline-block;\n}\n.ngx-datatable .datatable-body .datatable-row-detail {\n  overflow-y: hidden;\n}\n.ngx-datatable .datatable-body .datatable-row-wrapper {\n  display: flex;\n  flex-direction: column;\n}\n.ngx-datatable .datatable-body .datatable-body-row {\n  outline: none;\n}\n.ngx-datatable .datatable-body .datatable-body-row > div {\n  display: flex;\n  border-bottom: 1px solid #f1f1f1;\n}\n.ngx-datatable .datatable-footer {\n  display: block;\n  width: 100%;\n}\n.ngx-datatable .datatable-footer .datatable-footer-inner {\n  display: flex;\n  align-items: center;\n  width: 100%;\n}\n.ngx-datatable .datatable-footer .selected-count .page-count {\n  flex: 1 1 40%;\n}\n.ngx-datatable .datatable-footer .selected-count .datatable-pager {\n  flex: 1 1 60%;\n}\n.ngx-datatable .datatable-footer .page-count {\n  flex: 1 1 20%;\n}\n.ngx-datatable .datatable-footer .datatable-pager {\n  flex: 1 1 80%;\n  text-align: right;\n}\n.ngx-datatable .datatable-footer .datatable-pager .pager,\n.ngx-datatable .datatable-footer .datatable-pager .pager li {\n  padding: 0;\n  margin: 0;\n  display: inline-block;\n  list-style: none;\n}\n.ngx-datatable .datatable-footer .datatable-pager .pager li, .ngx-datatable .datatable-footer .datatable-pager .pager li a {\n  outline: none;\n}\n.ngx-datatable .datatable-footer .datatable-pager .pager li a {\n  cursor: pointer;\n  display: inline-block;\n}\n.ngx-datatable .datatable-footer .datatable-pager .pager li.disabled a {\n  cursor: not-allowed;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hc3NldHMvc2Nzcy9uZ3hkYXRhdGFibGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUNBQUE7RUFZQTs7SUFBQTtFQWFBOztJQUFBO0VBVUE7O0lBQUE7RUFnQkE7O0lBQUE7RUEyQkE7O0lBQUE7RUE0Q0E7O0lBQUE7RUE4REE7O0lBQUE7RUE4Q0E7O0lBQUE7QUE3TUo7QUF2Qkk7RUFDRSx3QkFBQTtBQXlCTjtBQXRCSTtFQUdFLHNCQUFBO0FBd0JOO0FBakJNO0VBQ0UsZ0JBQUE7QUFtQlI7QUFsQlE7RUFDRSxrQkFBQTtBQW9CVjtBQVZNO0VBRUUsaUNBQUE7QUFXUjtBQUZRO0VBQ0UsbUJBQUE7QUFJVjtBQUhVO0VBQ0UsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBS1o7QUFLTTtFQUNFLG1CQUFBO0FBSFI7QUFLUTtFQUNFLG1CQUFBO0FBSFY7QUFNVTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGdDQUFBO0FBSlo7QUFPVTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUxaO0FBY0k7OztFQU9FLGFBQUE7RUFFQSxtQkFBQTtFQUlBLGlCQUFBO0VBQ0EsY0FBQTtBQWJOO0FBZ0JJOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0NBQUE7QUFkTjtBQWVNOztFQUNFLGFBQUE7QUFaUjtBQWdCSTs7RUFFRSxVQUFBO0FBZE47QUFpQkk7Ozs7RUFJRSxrQkFBQTtBQWZOO0FBcUJJO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0FBbkJOO0FBcUJNO0VBQ0Usb0JBQUE7RUFDQSw0QkFBQTtBQW5CUjtBQXNCTTtFQUNFLGtCQUFBO0VBQ0EscUJBQUE7QUFwQlI7QUF1QlU7RUFDRSxlQUFBO0FBckJaO0FBeUJRO0VBQ0UsWUFBQTtBQXZCVjtBQTBCUTtFQUNFLGlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7QUF4QlY7QUEyQlE7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQXpCVjtBQTRCUTtFQUNFLGlCQUFBO0FBMUJWO0FBOEJVO0VBQ0UsbUJBQUE7QUE1Qlo7QUFpQ1U7RUFDRSxtQkFBQTtBQS9CWjtBQXdDSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7QUF0Q047QUF3Q007RUFDRSxxQkFBQTtBQXRDUjtBQXlDTTtFQUNFLGtCQUFBO0FBdkNSO0FBMENNO0VBS0UsYUFBQTtFQVFBLHNCQUFBO0FBekNSO0FBNENNO0VBQ0UsYUFBQTtBQTFDUjtBQTRDUTtFQUtFLGFBQUE7RUFDQSxnQ0FBQTtBQTFDVjtBQWtESTtFQUNFLGNBQUE7RUFDQSxXQUFBO0FBaEROO0FBa0RNO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQWhEUjtBQW9EUTtFQUNFLGFBQUE7QUFsRFY7QUFvRFE7RUFDRSxhQUFBO0FBbERWO0FBc0RNO0VBQ0UsYUFBQTtBQXBEUjtBQXVETTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtBQXJEUjtBQXVEUTs7RUFFRSxVQUFBO0VBQ0EsU0FBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7QUFyRFY7QUF5RFU7RUFDRSxhQUFBO0FBdkRaO0FBMkRZO0VBQ0UsZUFBQTtFQUNBLHFCQUFBO0FBekRkO0FBNERZO0VBQ0UsbUJBQUE7QUExRGQiLCJmaWxlIjoic3JjL2Fzc2V0cy9zY3NzL25neGRhdGF0YWJsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uZ3gtZGF0YXRhYmxlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgb3ZlcmZsb3c6aGlkZGVuO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XHJcbiAgXHJcbiAgICBbaGlkZGVuXSB7XHJcbiAgICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIH1cclxuICBcclxuICAgICosICo6YmVmb3JlLCAqOmFmdGVyIHtcclxuICAgICAgLW1vei1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICB9XHJcbiAgXHJcbiAgICAvKipcclxuICAgICAqIFZlcnRpY2FsIFNjcm9sbGluZyBBZGp1c3RtZW50c1xyXG4gICAgICovXHJcbiAgICAmLnNjcm9sbC12ZXJ0aWNhbCB7XHJcbiAgICAgIC5kYXRhdGFibGUtYm9keSB7XHJcbiAgICAgICAgb3ZlcmZsb3cteTphdXRvO1xyXG4gICAgICAgIC5kYXRhdGFibGUtcm93LXdyYXBwZXIge1xyXG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIH1cclxuICBcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIFxyXG4gICAgLyoqXHJcbiAgICAgKiBIb3Jpem9udGFsIFNjcm9sbGluZyBBZGp1c3RtZW50c1xyXG4gICAgICovXHJcbiAgICAmLnNjcm9sbC1ob3J6IHtcclxuICAgICAgLmRhdGF0YWJsZS1ib2R5IHtcclxuICAgICAgICAvLyBvdmVyZmxvdy14OmF1dG87XHJcbiAgICAgICAgLXdlYmtpdC1vdmVyZmxvdy1zY3JvbGxpbmc6IHRvdWNoO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgXHJcbiAgICAvKipcclxuICAgICAqIEZpeGVkIEhlYWRlciBIZWlnaHQgQWRqdXN0bWVudHNcclxuICAgICAqL1xyXG4gICAgJi5maXhlZC1oZWFkZXIge1xyXG4gICAgICAuZGF0YXRhYmxlLWhlYWRlciB7XHJcbiAgICAgICAgLmRhdGF0YWJsZS1oZWFkZXItaW5uZXJ7XHJcbiAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgICAgICAgLmRhdGF0YWJsZS1oZWFkZXItY2VsbHtcclxuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgXHJcbiAgICAvKipcclxuICAgICAqIEZpeGVkIHJvdyBoZWlnaHQgYWRqdXN0bWVudHNcclxuICAgICAqL1xyXG4gICAgJi5maXhlZC1yb3cge1xyXG4gICAgICAuZGF0YXRhYmxlLXNjcm9sbHtcclxuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC5kYXRhdGFibGUtYm9keS1yb3cge1xyXG4gICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICAgXHJcbiAgXHJcbiAgICAgICAgICAuZGF0YXRhYmxlLWJvZHktY2VsbCB7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgICAgICAgICB3b3JkLWJyZWFrOiBicmVhay1hbGwgIWltcG9ydGFudDtcclxuICAgICAgICAgIH1cclxuICBcclxuICAgICAgICAgIC5kYXRhdGFibGUtYm9keS1ncm91cC1jZWxsIHtcclxuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICAgICAgICB9ICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICBcclxuICAgIC8qKlxyXG4gICAgICogU2hhcmVkIFN0eWxlc1xyXG4gICAgICovXHJcbiAgICAuZGF0YXRhYmxlLWJvZHktcm93LFxyXG4gICAgLmRhdGF0YWJsZS1yb3ctY2VudGVyLFxyXG4gICAgLmRhdGF0YWJsZS1oZWFkZXItaW5uZXIge1xyXG4gICAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcclxuICAgICAgZGlzcGxheTogLW1vei1ib3g7XHJcbiAgICAgIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xyXG4gICAgICBkaXNwbGF5OiAtd2Via2l0LWZsZXg7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgXHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgIC13ZWJraXQtZmxleC1mbG93OiByb3c7XHJcbiAgICAgIC1tb3otZmxleC1mbG93OiByb3c7XHJcbiAgICAgIC1tcy1mbGV4LWZsb3c6IHJvdztcclxuICAgICAgLW8tZmxleC1mbG93OiByb3c7XHJcbiAgICAgIGZsZXgtZmxvdzogcm93O1xyXG4gICAgfVxyXG4gIFxyXG4gICAgLmRhdGF0YWJsZS1ib2R5LWNlbGwsXHJcbiAgICAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIHtcclxuICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAxLjYyNTtcclxuICAgICAgd29yZC1icmVhazogYnJlYWstYWxsICFpbXBvcnRhbnQ7XHJcbiAgICAgICY6Zm9jdXMge1xyXG4gICAgICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICBcclxuICAgIC5kYXRhdGFibGUtcm93LWxlZnQsXHJcbiAgICAuZGF0YXRhYmxlLXJvdy1yaWdodCB7XHJcbiAgICAgIHotaW5kZXg6IDk7XHJcbiAgICB9XHJcbiAgXHJcbiAgICAuZGF0YXRhYmxlLXJvdy1sZWZ0LFxyXG4gICAgLmRhdGF0YWJsZS1yb3ctY2VudGVyLFxyXG4gICAgLmRhdGF0YWJsZS1yb3ctZ3JvdXAsXHJcbiAgICAuZGF0YXRhYmxlLXJvdy1yaWdodCB7XHJcbiAgICAgIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG4gICAgfVxyXG4gIFxyXG4gICAgLyoqXHJcbiAgICAgKiBIZWFkZXIgU3R5bGVzXHJcbiAgICAgKi9cclxuICAgIC5kYXRhdGFibGUtaGVhZGVyIHtcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgXHJcbiAgICAgIC5kYXRhdGFibGUtaGVhZGVyLWlubmVye1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBzdHJldGNoO1xyXG4gICAgICAgIC13ZWJraXQtYWxpZ24taXRlbXM6IHN0cmV0Y2g7XHJcbiAgICAgIH1cclxuICBcclxuICAgICAgLmRhdGF0YWJsZS1oZWFkZXItY2VsbCB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBcclxuICAgICAgICAmLnNvcnRhYmxlIHtcclxuICAgICAgICAgIC5kYXRhdGFibGUtaGVhZGVyLWNlbGwtd3JhcHBlciB7XHJcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgJi5sb25ncHJlc3MgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyIHtcclxuICAgICAgICAgIGN1cnNvcjogbW92ZTtcclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgLnNvcnQtYnRuIHtcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgLnJlc2l6ZS1oYW5kbGUsIC5yZXNpemUtaGFuZGxlLS1ub3QtcmVzaXphYmxlIHtcclxuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICAgICAgdG9wOiAwO1xyXG4gICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgd2lkdGg6IDVweDtcclxuICAgICAgICAgIHBhZGRpbmc6IDAgNHB4O1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gICAgICAgIH1cclxuICBcclxuICAgICAgICAucmVzaXplLWhhbmRsZSB7XHJcbiAgICAgICAgICBjdXJzb3I6IGV3LXJlc2l6ZTtcclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgJi5yZXNpemVhYmxlOmhvdmVyIHtcclxuICAgICAgICAgIC5yZXNpemUtaGFuZGxle1xyXG4gICAgICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICBcclxuICAgICAgICAmOmhvdmVyIHtcclxuICAgICAgICAgIC5yZXNpemUtaGFuZGxlLS1ub3QtcmVzaXphYmxlIHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICBcclxuICAgIC8qKlxyXG4gICAgICogQm9keSBTdHlsZXNcclxuICAgICAqL1xyXG4gICAgLmRhdGF0YWJsZS1ib2R5IHtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB6LWluZGV4OiAxMDtcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgXHJcbiAgICAgIC5kYXRhdGFibGUtc2Nyb2xse1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAuZGF0YXRhYmxlLXJvdy1kZXRhaWwge1xyXG4gICAgICAgIG92ZXJmbG93LXk6IGhpZGRlbjtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAuZGF0YXRhYmxlLXJvdy13cmFwcGVyIHtcclxuICAgICAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcclxuICAgICAgICBkaXNwbGF5OiAtbW96LWJveDtcclxuICAgICAgICBkaXNwbGF5OiAtbXMtZmxleGJveDtcclxuICAgICAgICBkaXNwbGF5OiAtd2Via2l0LWZsZXg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICBcclxuICAgICAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xyXG4gICAgICAgIC13ZWJraXQtYm94LWRpcmVjdGlvbjogbm9ybWFsO1xyXG4gICAgICAgIC13ZWJraXQtZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICAtbW96LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xyXG4gICAgICAgIC1tb3otYm94LWRpcmVjdGlvbjogbm9ybWFsO1xyXG4gICAgICAgIC1tcy1mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgIH1cclxuICBcclxuICAgICAgLmRhdGF0YWJsZS1ib2R5LXJvdyB7XHJcbiAgICAgICAgb3V0bGluZTpub25lO1xyXG4gIFxyXG4gICAgICAgID4gZGl2IHtcclxuICAgICAgICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xyXG4gICAgICAgICAgZGlzcGxheTogLW1vei1ib3g7XHJcbiAgICAgICAgICBkaXNwbGF5OiAtbXMtZmxleGJveDtcclxuICAgICAgICAgIGRpc3BsYXk6IC13ZWJraXQtZmxleDtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2YxZjFmMTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICBcclxuICAgIC8qKlxyXG4gICAgICogRm9vdGVyIFN0eWxlc1xyXG4gICAgICovXHJcbiAgICAuZGF0YXRhYmxlLWZvb3RlciB7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICBcclxuICAgICAgLmRhdGF0YWJsZS1mb290ZXItaW5uZXIge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAuc2VsZWN0ZWQtY291bnQge1xyXG4gICAgICAgIC5wYWdlLWNvdW50IHtcclxuICAgICAgICAgIGZsZXg6IDEgMSA0MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kYXRhdGFibGUtcGFnZXIge1xyXG4gICAgICAgICAgZmxleDogMSAxIDYwJTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICBcclxuICAgICAgLnBhZ2UtY291bnR7XHJcbiAgICAgICAgZmxleDogMSAxIDIwJTtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAuZGF0YXRhYmxlLXBhZ2Vye1xyXG4gICAgICAgIGZsZXg6IDEgMSA4MCU7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgXHJcbiAgICAgICAgLnBhZ2VyLFxyXG4gICAgICAgIC5wYWdlciBsaSB7XHJcbiAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgbGlzdC1zdHlsZTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgLnBhZ2VyIHtcclxuICAgICAgICAgIGxpLCBsaSBhe1xyXG4gICAgICAgICAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgICAgICAgfVxyXG4gIFxyXG4gICAgICAgICAgbGkge1xyXG4gICAgICAgICAgICBhIHtcclxuICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgICB9XHJcbiAgXHJcbiAgICAgICAgICAgICYuZGlzYWJsZWQgYSB7XHJcbiAgICAgICAgICAgICAgY3Vyc29yOiBub3QtYWxsb3dlZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0iXX0= */", ".ngx-datatable.material {\n  background: #FFF;\n  /**\n   * Shared Styles\n   */\n  /**\n   * Global Row Styles\n   */\n  /**\n   * Header Styles\n   */\n  /**\n   * Body Styles\n   */\n  /**\n   * Footer Styles\n   */\n}\n.ngx-datatable.material.striped .datatable-row-odd {\n  background: #eee;\n}\n.ngx-datatable.material.single-selection .datatable-body-row.active, .ngx-datatable.material.single-selection .datatable-body-row.active .datatable-row-group, .ngx-datatable.material.multi-selection .datatable-body-row.active, .ngx-datatable.material.multi-selection .datatable-body-row.active .datatable-row-group, .ngx-datatable.material.multi-click-selection .datatable-body-row.active, .ngx-datatable.material.multi-click-selection .datatable-body-row.active .datatable-row-group {\n  background-color: #feffd2;\n  color: #FFF;\n}\n.ngx-datatable.material.single-selection .datatable-body-row.active:hover, .ngx-datatable.material.single-selection .datatable-body-row.active:hover .datatable-row-group, .ngx-datatable.material.multi-selection .datatable-body-row.active:hover, .ngx-datatable.material.multi-selection .datatable-body-row.active:hover .datatable-row-group, .ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover, .ngx-datatable.material.multi-click-selection .datatable-body-row.active:hover .datatable-row-group {\n  background-color: #feffd2;\n  color: #FFF;\n}\n.ngx-datatable.material.single-selection .datatable-body-row.active:focus, .ngx-datatable.material.single-selection .datatable-body-row.active:focus .datatable-row-group, .ngx-datatable.material.multi-selection .datatable-body-row.active:focus, .ngx-datatable.material.multi-selection .datatable-body-row.active:focus .datatable-row-group, .ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus, .ngx-datatable.material.multi-click-selection .datatable-body-row.active:focus .datatable-row-group {\n  background-color: #feffd2;\n  color: #FFF;\n}\n.ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover, .ngx-datatable.material:not(.cell-selection) .datatable-body-row:hover .datatable-row-group {\n  background-color: #eee;\n  transition-property: background;\n  transition-duration: 0.3s;\n  transition-timing-function: linear;\n}\n.ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus, .ngx-datatable.material:not(.cell-selection) .datatable-body-row:focus .datatable-row-group {\n  background-color: #ddd;\n}\n.ngx-datatable.material.cell-selection .datatable-body-cell:hover, .ngx-datatable.material.cell-selection .datatable-body-cell:hover .datatable-row-group {\n  background-color: #eee;\n  transition-property: background;\n  transition-duration: 0.3s;\n  transition-timing-function: linear;\n}\n.ngx-datatable.material.cell-selection .datatable-body-cell:focus, .ngx-datatable.material.cell-selection .datatable-body-cell:focus .datatable-row-group {\n  background-color: #ddd;\n}\n.ngx-datatable.material.cell-selection .datatable-body-cell.active, .ngx-datatable.material.cell-selection .datatable-body-cell.active .datatable-row-group {\n  background-color: #feffd2;\n  color: #FFF;\n}\n.ngx-datatable.material.cell-selection .datatable-body-cell.active:hover, .ngx-datatable.material.cell-selection .datatable-body-cell.active:hover .datatable-row-group {\n  background-color: #feffd2;\n  color: #FFF;\n}\n.ngx-datatable.material.cell-selection .datatable-body-cell.active:focus, .ngx-datatable.material.cell-selection .datatable-body-cell.active:focus .datatable-row-group {\n  background-color: #feffd2;\n  color: #FFF;\n}\n.ngx-datatable.material .empty-row {\n  height: 50px;\n  text-align: left;\n  padding: 0.5rem 1.2rem;\n  vertical-align: top;\n  border-top: 0;\n}\n.ngx-datatable.material .loading-row {\n  text-align: left;\n  padding: 0.5rem 1.2rem;\n  vertical-align: top;\n  border-top: 0;\n}\n.ngx-datatable.material .datatable-header .datatable-row-left,\n.ngx-datatable.material .datatable-body .datatable-row-left {\n  background: inherit;\n  background-position: 100% 0;\n  background-repeat: repeat-y;\n  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQIHWPSkNeSBmJhTQVtbiDNCgASagIIuJX8OgAAAABJRU5ErkJggg==);\n}\n.ngx-datatable.material .datatable-header .datatable-row-right,\n.ngx-datatable.material .datatable-body .datatable-row-right {\n  background-position: 0 0;\n  background-color: #fff;\n  background-repeat: repeat-y;\n  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAABCAYAAAD5PA/NAAAAFklEQVQI12PQkNdi1VTQ5gbSwkAsDQARLAIGtOSFUAAAAABJRU5ErkJggg==);\n}\n.ngx-datatable.material .datatable-header {\n  border-bottom: 1px solid rgba(0, 0, 0, 0.12);\n}\n.ngx-datatable.material .datatable-header .datatable-header-cell {\n  text-align: left;\n  padding: 0.4rem 1.2rem;\n  font-weight: bold;\n  border-right: 1px solid #e7e7e7;\n  vertical-align: bottom;\n  font-size: 11px;\n}\n.ngx-datatable.material .datatable-header .datatable-header-cell .datatable-header-cell-wrapper {\n  position: relative;\n}\n.ngx-datatable.material .datatable-header .datatable-header-cell.longpress .draggable::after {\n  transition: transform 400ms ease, opacity 400ms ease;\n  opacity: 0.5;\n  transform: scale(1);\n}\n.ngx-datatable.material .datatable-header .datatable-header-cell .draggable::after {\n  content: \" \";\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  margin: -30px 0 0 -30px;\n  height: 60px;\n  width: 60px;\n  background: #eee;\n  border-radius: 100%;\n  opacity: 1;\n  filter: none;\n  transform: scale(0);\n  z-index: 9999;\n  pointer-events: none;\n}\n.ngx-datatable.material .datatable-header .datatable-header-cell.dragging .resize-handle {\n  border-right: none;\n}\n.ngx-datatable.material .datatable-header .resize-handle {\n  border-right: solid 1px #eee;\n}\n.ngx-datatable.material .datatable-body .datatable-row-detail {\n  background: #f5f5f5;\n  padding: 10px;\n}\n.ngx-datatable.material .datatable-body .datatable-group-header {\n  background: #f5f5f5;\n  border-bottom: solid 1px #D9D8D9;\n  border-top: solid 1px #D9D8D9;\n}\n.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-cell {\n  text-align: left;\n  padding: 0.3rem 1.2rem;\n  vertical-align: top;\n  border-top: 0;\n  color: rgba(0, 0, 0, 0.87);\n  transition: width 0.3s ease;\n  font-size: 11px;\n  font-weight: 400;\n}\n.ngx-datatable.material .datatable-body .datatable-body-row .datatable-body-group-cell {\n  text-align: left;\n  padding: 0.9rem 1.2rem;\n  vertical-align: top;\n  border-top: 0;\n  color: rgba(0, 0, 0, 0.87);\n  transition: width 0.3s ease;\n  font-size: 14px;\n  font-weight: 400;\n}\n.ngx-datatable.material .datatable-body .progress-linear {\n  display: block;\n  position: relative;\n  width: 100%;\n  height: 5px;\n  padding: 0;\n  margin: 0;\n  position: absolute;\n}\n.ngx-datatable.material .datatable-body .progress-linear .container {\n  display: block;\n  position: relative;\n  overflow: hidden;\n  width: 100%;\n  height: 5px;\n  transform: translate(0, 0) scale(1, 1);\n  background-color: #aad1f9;\n}\n.ngx-datatable.material .datatable-body .progress-linear .container .bar {\n  transition: all 0.2s linear;\n  animation: query 0.8s infinite cubic-bezier(0.39, 0.575, 0.565, 1);\n  transition: transform 0.2s linear;\n  background-color: #106cc8;\n  position: absolute;\n  left: 0;\n  top: 0;\n  bottom: 0;\n  width: 100%;\n  height: 5px;\n}\n.ngx-datatable.material .datatable-footer {\n  border-top: 1px solid rgba(0, 0, 0, 0.12);\n  font-size: 12px;\n  font-weight: 400;\n  color: rgba(0, 0, 0, 0.54);\n  background: #ffffff;\n}\n.ngx-datatable.material .datatable-footer .datatable-footer-inner {\n  height: 45px !important;\n}\n.ngx-datatable.material .datatable-footer .page-count {\n  line-height: 50px;\n  height: 50px;\n  padding: 0 1.2rem;\n}\n.ngx-datatable.material .datatable-footer .datatable-pager {\n  margin: 0 10px;\n}\n.ngx-datatable.material .datatable-footer .datatable-pager li {\n  vertical-align: middle;\n}\n.ngx-datatable.material .datatable-footer .datatable-pager li.disabled a {\n  color: rgba(0, 0, 0, 0.26) !important;\n  background-color: transparent !important;\n}\n.ngx-datatable.material .datatable-footer .datatable-pager li.active a {\n  background-color: rgba(158, 158, 158, 0.2);\n  font-weight: bold;\n}\n.ngx-datatable.material .datatable-footer .datatable-pager a {\n  height: 22px;\n  min-width: 24px;\n  line-height: 22px;\n  padding: 0 6px;\n  border-radius: 3px;\n  margin: 6px 3px;\n  text-align: center;\n  vertical-align: top;\n  color: rgba(0, 0, 0, 0.54);\n  text-decoration: none;\n  vertical-align: bottom;\n}\n.ngx-datatable.material .datatable-footer .datatable-pager a:hover {\n  color: rgba(0, 0, 0, 0.75);\n  background-color: rgba(158, 158, 158, 0.2);\n}\n.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-left,\n.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-skip,\n.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-right,\n.ngx-datatable.material .datatable-footer .datatable-pager .datatable-icon-prev {\n  font-size: 20px;\n  line-height: 20px;\n  padding: 0 3px;\n}\n/**\n * Checkboxes\n**/\n.datatable-checkbox {\n  position: relative;\n  margin: 0;\n  cursor: pointer;\n  vertical-align: middle;\n  display: inline-block;\n  box-sizing: border-box;\n  padding: 0;\n}\n.datatable-checkbox input[type=checkbox] {\n  position: relative;\n  margin: 0 1rem 0 0;\n  cursor: pointer;\n  outline: none;\n}\n.datatable-checkbox input[type=checkbox]:before {\n  transition: all 0.3s ease-in-out;\n  content: \"\";\n  position: absolute;\n  left: 0;\n  z-index: 1;\n  width: 1rem;\n  height: 1rem;\n  border: 2px solid #f2f2f2;\n}\n.datatable-checkbox input[type=checkbox]:checked:before {\n  transform: rotate(-45deg);\n  height: 0.5rem;\n  border-color: #009688;\n  border-top-style: none;\n  border-right-style: none;\n}\n.datatable-checkbox input[type=checkbox]:after {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 1rem;\n  height: 1rem;\n  background: #fff;\n  cursor: pointer;\n}\n/**\n * Progress bar animations\n */\n@keyframes query {\n  0% {\n    opacity: 1;\n    transform: translateX(35%) scale(0.3, 1);\n  }\n  100% {\n    opacity: 0;\n    transform: translateX(-50%) scale(0, 1);\n  }\n}\n.datatable-row-even {\n  background: white;\n}\n.datatable-row-odd {\n  background-color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hc3NldHMvc2Nzcy9tYXRlcmlhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsZ0JBQUE7RUFxRkE7O0lBQUE7RUFrQkE7O0lBQUE7RUFtQkE7O0lBQUE7RUEwREE7O0lBQUE7RUFtRkE7O0lBQUE7QUF2UEQ7QUFaRTtFQUNDLGdCQUFBO0FBY0g7QUFORztFQUVDLHlCQUFBO0VBQ0ksV0FBQTtBQU9SO0FBSkc7RUFFQyx5QkFBQTtFQUNJLFdBQUE7QUFLUjtBQUZHO0VBRUMseUJBQUE7RUFDSSxXQUFBO0FBR1I7QUFJTTtFQUVDLHNCQUFBO0VBQ0EsK0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBSFA7QUFNRztFQUVDLHNCQUFBO0FBTEo7QUFZTTtFQUVDLHNCQUFBO0VBQ0EsK0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtDQUFBO0FBWFA7QUFjRztFQUVDLHNCQUFBO0FBYko7QUFnQkc7RUFFQyx5QkFBQTtFQUNJLFdBQUE7QUFmUjtBQWtCRztFQUVDLHlCQUFBO0VBQ0ksV0FBQTtBQWpCUjtBQW9CRztFQUVDLHlCQUFBO0VBQ0ksV0FBQTtBQW5CUjtBQTJCQztFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0FBekJIO0FBNEJDO0VBQ0UsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtBQTFCSDtBQWtDRTs7RUFDQyxtQkFBQTtFQUNBLDJCQUFBO0VBQ0EsMkJBQUE7RUFDQSx5SkFBQTtBQS9CSDtBQWlDRTs7RUFDQyx3QkFBQTtFQUNFLHNCQUFBO0VBQ0EsMkJBQUE7RUFDQSx5SkFBQTtBQTlCTDtBQXFDQztFQUNHLDRDQUFBO0FBbkNKO0FBcUNJO0VBQ0UsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBRUgsK0JBQUE7RUFDRyxzQkFBQTtFQUNILGVBQUE7QUFwQ0g7QUF3Q007RUFDRSxrQkFBQTtBQXRDUjtBQTBDUTtFQUNFLG9EQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBeENWO0FBNENNO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUExQ1I7QUE4Q0k7RUFDQyxrQkFBQTtBQTVDTDtBQWlESTtFQUNFLDRCQUFBO0FBL0NOO0FBdURFO0VBQ0MsbUJBQUE7RUFDQSxhQUFBO0FBckRIO0FBd0RJO0VBQ0UsbUJBQUE7RUFDQSxnQ0FBQTtFQUNBLDZCQUFBO0FBdEROO0FBMERLO0VBQ0UsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNDLDBCQUFBO0VBQ0QsMkJBQUE7RUFDQyxlQUFBO0VBQ0osZ0JBQUE7QUF4REo7QUFnRUs7RUFDRSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0MsMEJBQUE7RUFDRCwyQkFBQTtFQUNDLGVBQUE7RUFDQSxnQkFBQTtBQTlEUjtBQWtFRTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDRSxrQkFBQTtBQWhFTjtBQWtFRztFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFFQSxzQ0FBQTtFQUNBLHlCQUFBO0FBaEVMO0FBa0VJO0VBQ0UsMkJBQUE7RUFFQSxrRUFBQTtFQUdBLGlDQUFBO0VBQ0EseUJBQUE7RUFFQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBbEVOO0FBMkVDO0VBQ0MseUNBQUE7RUFDQSxlQUFBO0VBQ0UsZ0JBQUE7RUFDRiwwQkFBQTtFQUNBLG1CQUFBO0FBekVGO0FBMEVFO0VBRUMsdUJBQUE7QUF6RUg7QUEyRUU7RUFDQyxpQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQXpFSDtBQTRFRTtFQUNDLGNBQUE7QUExRUg7QUE0RUc7RUFDRyxzQkFBQTtBQTFFTjtBQTRFSTtFQUNDLHFDQUFBO0VBQ0Esd0NBQUE7QUExRUw7QUE2RUk7RUFDQywwQ0FBQTtFQUNBLGlCQUFBO0FBM0VMO0FBK0VHO0VBQ0MsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxxQkFBQTtFQUNFLHNCQUFBO0FBN0VOO0FBK0VJO0VBQ0MsMEJBQUE7RUFDQSwwQ0FBQTtBQTdFTDtBQWlGRzs7OztFQUlDLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUEvRUo7QUFxRkE7O0VBQUE7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxVQUFBO0FBbEZGO0FBb0ZFO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBbEZKO0FBb0ZJO0VBR0UsZ0NBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFsRk47QUFxRkk7RUFJRSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0JBQUE7QUFuRk47QUFzRkk7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBcEZOO0FBeUZBOztFQUFBO0FBR0E7RUFDRTtJQUNFLFVBQUE7SUFDQSx3Q0FBQTtFQXRGRjtFQXlGQTtJQUNFLFVBQUE7SUFDQSx1Q0FBQTtFQXZGRjtBQUNGO0FBMEZBO0VBRUEsaUJBQUE7QUF6RkE7QUEyRkE7RUFFQyx1QkFBQTtBQXpGRCIsImZpbGUiOiJzcmMvYXNzZXRzL3Njc3MvbWF0ZXJpYWwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIHtcclxuXHRiYWNrZ3JvdW5kOiNGRkY7XHJcbiAgLy8gYm94LXNoYWRvdzogMCA1cHggNXB4IC0zcHggcmdiYSgwLDAsMCwuMiksIDAgOHB4IDEwcHggMXB4IHJnYmEoMCwwLDAsLjE0KSwgMCAzcHggMTRweCAycHggcmdiYSgwLDAsMCwuMTIpO1xyXG5cclxuXHQmLnN0cmlwZWQge1xyXG5cdFx0LmRhdGF0YWJsZS1yb3ctb2RkIHtcclxuXHRcdFx0YmFja2dyb3VuZDogI2VlZTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG4gICYuc2luZ2xlLXNlbGVjdGlvbixcclxuICAmLm11bHRpLXNlbGVjdGlvbixcclxuICAmLm11bHRpLWNsaWNrLXNlbGVjdGlvbiB7XHJcbiAgICAuZGF0YXRhYmxlLWJvZHktcm93IHtcclxuXHRcdFx0Ji5hY3RpdmUsXHJcblx0XHRcdCYuYWN0aXZlIC5kYXRhdGFibGUtcm93LWdyb3VwIHtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmVmZmQyO1xyXG4gICAgICAgIGNvbG9yOiAjRkZGO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQmLmFjdGl2ZTpob3ZlcixcclxuXHRcdFx0Ji5hY3RpdmU6aG92ZXIgLmRhdGF0YWJsZS1yb3ctZ3JvdXAge1xyXG5cdFx0XHRcdGJhY2tncm91bmQtY29sb3I6ICNmZWZmZDI7XHJcbiAgICAgICAgY29sb3I6ICNGRkY7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCYuYWN0aXZlOmZvY3VzLFxyXG5cdFx0XHQmLmFjdGl2ZTpmb2N1cyAuZGF0YXRhYmxlLXJvdy1ncm91cCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogI2ZlZmZkMjtcclxuICAgICAgICBjb2xvcjogI0ZGRjtcclxuXHRcdFx0fVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgJjpub3QoLmNlbGwtc2VsZWN0aW9uKSB7XHJcbiAgICAuZGF0YXRhYmxlLWJvZHktcm93IHtcclxuICAgICAgJjpob3ZlcixcclxuXHRcdFx0Jjpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cCB7XHJcblx0ICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2VlZTtcclxuXHQgICAgICB0cmFuc2l0aW9uLXByb3BlcnR5OiBiYWNrZ3JvdW5kO1xyXG5cdCAgICAgIHRyYW5zaXRpb24tZHVyYXRpb246IC4zcztcclxuXHQgICAgICB0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjogbGluZWFyO1xyXG5cdCAgICB9XHJcblxyXG5cdFx0XHQmOmZvY3VzLFxyXG5cdFx0XHQmOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3VwIHtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkO1xyXG5cdFx0XHR9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAmLmNlbGwtc2VsZWN0aW9uIHtcclxuICAgIC5kYXRhdGFibGUtYm9keS1jZWxsIHtcclxuICAgICAgJjpob3ZlcixcclxuXHRcdFx0Jjpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cCB7XHJcblx0ICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2VlZTtcclxuXHQgICAgICB0cmFuc2l0aW9uLXByb3BlcnR5OiBiYWNrZ3JvdW5kO1xyXG5cdCAgICAgIHRyYW5zaXRpb24tZHVyYXRpb246IC4zcztcclxuXHQgICAgICB0cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvbjogbGluZWFyO1xyXG5cdCAgICB9XHJcblxyXG5cdFx0XHQmOmZvY3VzLFxyXG5cdFx0XHQmOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3VwIHtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQmLmFjdGl2ZSxcclxuXHRcdFx0Ji5hY3RpdmUgLmRhdGF0YWJsZS1yb3ctZ3JvdXAge1xyXG5cdFx0XHRcdGJhY2tncm91bmQtY29sb3I6ICNmZWZmZDI7XHJcbiAgICAgICAgY29sb3I6ICNGRkY7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdCYuYWN0aXZlOmhvdmVyLFxyXG5cdFx0XHQmLmFjdGl2ZTpob3ZlciAuZGF0YXRhYmxlLXJvdy1ncm91cCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogI2ZlZmZkMjtcclxuICAgICAgICBjb2xvcjogI0ZGRjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Ji5hY3RpdmU6Zm9jdXMsXHJcblx0XHRcdCYuYWN0aXZlOmZvY3VzIC5kYXRhdGFibGUtcm93LWdyb3VwIHtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAjZmVmZmQyO1xyXG4gICAgICAgIGNvbG9yOiAjRkZGO1xyXG5cdFx0XHR9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuXHQvKipcclxuXHQgKiBTaGFyZWQgU3R5bGVzXHJcblx0ICovXHJcblx0LmVtcHR5LXJvd3tcclxuXHRcdCBoZWlnaHQ6NTBweDtcclxuXHRcdCB0ZXh0LWFsaWduOiBsZWZ0O1xyXG5cdFx0IHBhZGRpbmc6IC41cmVtIDEuMnJlbTtcclxuXHRcdCB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG5cdFx0IGJvcmRlci10b3A6IDA7XHJcblx0fVxyXG5cclxuXHQubG9hZGluZy1yb3d7XHJcblx0XHQgdGV4dC1hbGlnbjogbGVmdDtcclxuXHRcdCBwYWRkaW5nOiAuNXJlbSAxLjJyZW07XHJcblx0XHQgdmVydGljYWwtYWxpZ246IHRvcDtcclxuXHRcdCBib3JkZXItdG9wOiAwO1xyXG5cdH1cclxuXHJcblx0LyoqXHJcblx0ICogR2xvYmFsIFJvdyBTdHlsZXNcclxuXHQgKi9cclxuXHQgLmRhdGF0YWJsZS1oZWFkZXIsXHJcblx0IC5kYXRhdGFibGUtYm9keSB7XHJcblx0XHQuZGF0YXRhYmxlLXJvdy1sZWZ0IHtcclxuXHRcdFx0YmFja2dyb3VuZDogaW5oZXJpdDtcclxuXHRcdFx0YmFja2dyb3VuZC1wb3NpdGlvbjogMTAwJSAwO1xyXG5cdFx0XHRiYWNrZ3JvdW5kLXJlcGVhdDogcmVwZWF0LXk7XHJcblx0XHRcdGJhY2tncm91bmQtaW1hZ2U6IHVybChkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFRQUFBQUJDQVlBQUFENVBBL05BQUFBRmtsRVFWUUlIV1BTa05lU0JtSmhUUVZ0YmlETkNnQVNhZ0lJdUpYOE9nQUFBQUJKUlU1RXJrSmdnZz09KTtcclxuXHRcdH1cdCBcclxuXHRcdC5kYXRhdGFibGUtcm93LXJpZ2h0IHtcclxuXHRcdFx0YmFja2dyb3VuZC1wb3NpdGlvbjogMCAwO1xyXG5cdCAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG5cdCAgICBiYWNrZ3JvdW5kLXJlcGVhdDogcmVwZWF0LXk7XHJcblx0ICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybChkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFRQUFBQUJDQVlBQUFENVBBL05BQUFBRmtsRVFWUUkxMlBRa05kaTFWVFE1Z2JTd2tBc0RRQVJMQUlHdE9TRlVBQUFBQUJKUlU1RXJrSmdnZz09KTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC8qKlxyXG5cdCAqIEhlYWRlciBTdHlsZXNcclxuXHQgKi9cclxuXHQuZGF0YXRhYmxlLWhlYWRlciB7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxuXHJcbiAgICAuZGF0YXRhYmxlLWhlYWRlci1jZWxsIHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgcGFkZGluZzogMC40cmVtIDEuMnJlbTtcclxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcblx0XHRcdC8vIGNvbG9yOiByZ2IoMCwwLDApO1xyXG5cdFx0XHRib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNlN2U3ZTc7XHJcbiAgICAgIHZlcnRpY2FsLWFsaWduOiBib3R0b207XHJcblx0XHRcdGZvbnQtc2l6ZTogMTFweDtcclxuXHRcdCBcclxuICAgICAgIFxyXG5cclxuICAgICAgLmRhdGF0YWJsZS1oZWFkZXItY2VsbC13cmFwcGVyIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIH1cclxuXHJcblx0XHRcdCYubG9uZ3ByZXNzIHtcclxuICAgICAgICAuZHJhZ2dhYmxlOjphZnRlciB7XHJcbiAgICAgICAgICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gNDAwbXMgZWFzZSwgb3BhY2l0eSA0MDBtcyBlYXNlO1xyXG4gICAgICAgICAgb3BhY2l0eTogLjU7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xyXG4gICAgICAgIH1cclxuXHRcdFx0fVxyXG5cclxuICAgICAgLmRyYWdnYWJsZTo6YWZ0ZXIge1xyXG4gICAgICAgIGNvbnRlbnQ6IFwiIFwiO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IDUwJTtcclxuICAgICAgICBsZWZ0OiA1MCU7XHJcbiAgICAgICAgbWFyZ2luOiAtMzBweCAwIDAgLTMwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNlZWU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgICAgICBvcGFjaXR5OiAxO1xyXG4gICAgICAgIGZpbHRlcjogbm9uZTtcclxuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDApO1xyXG4gICAgICAgIHotaW5kZXg6IDk5OTk7XHJcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbiAgICAgIH1cclxuXHJcblx0XHRcdCYuZHJhZ2dpbmcge1xyXG5cdFx0XHRcdC5yZXNpemUtaGFuZGxlIHtcclxuXHRcdFx0XHRcdGJvcmRlci1yaWdodDogbm9uZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuICAgIH1cclxuXHJcbiAgICAucmVzaXplLWhhbmRsZSB7XHJcbiAgICAgIGJvcmRlci1yaWdodDpzb2xpZCAxcHggI2VlZTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cdC8qKlxyXG5cdCAqIEJvZHkgU3R5bGVzXHJcblx0ICovXHJcblx0LmRhdGF0YWJsZS1ib2R5IHtcclxuXHRcdC5kYXRhdGFibGUtcm93LWRldGFpbCB7XHJcblx0XHRcdGJhY2tncm91bmQ6ICNmNWY1ZjU7XHJcblx0XHRcdHBhZGRpbmc6IDEwcHg7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIC5kYXRhdGFibGUtZ3JvdXAtaGVhZGVyIHtcclxuICAgICAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcclxuICAgICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNEOUQ4RDk7XHJcbiAgICAgIGJvcmRlci10b3A6IHNvbGlkIDFweCAjRDlEOEQ5O1xyXG4gICAgfVxyXG5cclxuXHQgIC5kYXRhdGFibGUtYm9keS1yb3cge1xyXG5cdCAgICAuZGF0YXRhYmxlLWJvZHktY2VsbCB7XHJcblx0ICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuXHQgICAgICBwYWRkaW5nOiAuM3JlbSAxLjJyZW07XHJcblx0ICAgICAgdmVydGljYWwtYWxpZ246IHRvcDtcclxuXHQgICAgICBib3JkZXItdG9wOiAwO1xyXG4gICAgICAgIGNvbG9yOiByZ2JhKDAsMCwwLC44Nyk7XHJcblx0ICAgICAgdHJhbnNpdGlvbjogd2lkdGggMC4zcyBlYXNlO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuXHRcdFx0XHRmb250LXdlaWdodDogNDAwO1xyXG5cdFx0XHRcdC8vIGJhY2tncm91bmQ6d2hpdGU7XHJcblxyXG4gICAgICAgIC8vIGNlbGwgYWN0aXZlIGNsYXNzXHJcbiAgICAgICAgLy8gJi5hY3RpdmUge1xyXG4gICAgICAgIC8vICBiYWNrZ3JvdW5kOiAjMDgyOWUwXHJcbiAgICAgICAgLy8gfVxyXG5cdFx0XHR9XHJcblx0ICAgIC5kYXRhdGFibGUtYm9keS1ncm91cC1jZWxsIHtcclxuXHQgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG5cdCAgICAgIHBhZGRpbmc6IC45cmVtIDEuMnJlbTtcclxuXHQgICAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG5cdCAgICAgIGJvcmRlci10b3A6IDA7XHJcbiAgICAgICAgY29sb3I6IHJnYmEoMCwwLDAsLjg3KTtcclxuXHQgICAgICB0cmFuc2l0aW9uOiB3aWR0aCAwLjNzIGVhc2U7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcblx0ICAgIH1cdFx0XHRcdFx0XHJcblx0ICB9XHJcblxyXG5cdFx0LnByb2dyZXNzLWxpbmVhciB7XHJcblx0XHQgIGRpc3BsYXk6IGJsb2NrO1xyXG5cdFx0ICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHQgIHdpZHRoOiAxMDAlO1xyXG5cdFx0ICBoZWlnaHQ6IDVweDtcclxuXHRcdCAgcGFkZGluZzogMDtcclxuXHRcdCAgbWFyZ2luOiAwO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcblxyXG5cdFx0XHQuY29udGFpbmVyIHtcclxuXHRcdFx0ICBkaXNwbGF5OiBibG9jaztcclxuXHRcdFx0ICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHRcdCAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuXHRcdFx0ICB3aWR0aDogMTAwJTtcclxuXHRcdFx0ICBoZWlnaHQ6IDVweDtcclxuXHRcdFx0ICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlKDAsMCkgc2NhbGUoMSwxKTtcclxuXHRcdFx0ICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwLDApIHNjYWxlKDEsMSk7XHJcblx0XHRcdCAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE3MCwyMDksMjQ5KTtcclxuXHJcblx0XHRcdFx0LmJhciB7XHJcblx0XHRcdFx0ICB0cmFuc2l0aW9uOiBhbGwgLjJzIGxpbmVhcjtcclxuXHRcdFx0XHQgIC13ZWJraXQtYW5pbWF0aW9uOiBxdWVyeSAuOHMgaW5maW5pdGUgY3ViaWMtYmV6aWVyKC4zOSwuNTc1LC41NjUsMSk7XHJcblx0XHRcdFx0ICBhbmltYXRpb246IHF1ZXJ5IC44cyBpbmZpbml0ZSBjdWJpYy1iZXppZXIoLjM5LC41NzUsLjU2NSwxKTtcclxuXHJcblx0XHRcdFx0ICB0cmFuc2l0aW9uOiAtd2Via2l0LXRyYW5zZm9ybSAuMnMgbGluZWFyO1xyXG5cdFx0XHRcdCAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIC4ycyBsaW5lYXI7XHJcblx0XHRcdFx0ICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTYsMTA4LDIwMCk7XHJcblxyXG5cdFx0XHRcdCAgcG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdCAgbGVmdDogMDtcclxuXHRcdFx0XHQgIHRvcDogMDtcclxuXHRcdFx0XHQgIGJvdHRvbTogMDtcclxuXHRcdFx0XHQgIHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdCAgaGVpZ2h0OiA1cHg7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQvKipcclxuXHQgKiBGb290ZXIgU3R5bGVzXHJcblx0ICovXHJcblx0LmRhdGF0YWJsZS1mb290ZXIge1xyXG5cdFx0Ym9yZGVyLXRvcDogMXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgMC4xMik7XHJcblx0XHRmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG5cdFx0Y29sb3I6IHJnYmEoMCwwLDAsLjU0KTtcclxuXHRcdGJhY2tncm91bmQ6ICNmZmZmZmY7XHJcblx0XHQuZGF0YXRhYmxlLWZvb3Rlci1pbm5lclxyXG5cdFx0e1xyXG5cdFx0XHRoZWlnaHQ6IDQ1cHggIWltcG9ydGFudDtcclxuXHRcdH1cclxuXHRcdC5wYWdlLWNvdW50e1xyXG5cdFx0XHRsaW5lLWhlaWdodDogNTBweDtcclxuXHRcdFx0aGVpZ2h0OjUwcHg7XHJcblx0XHRcdHBhZGRpbmc6IDAgMS4ycmVtO1xyXG5cdFx0fVxyXG5cclxuXHRcdC5kYXRhdGFibGUtcGFnZXIge1xyXG5cdFx0XHRtYXJnaW46IDAgMTBweDtcclxuXHJcblx0XHRcdGxpIHtcclxuXHQgICAgXHR2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG5cclxuXHRcdFx0XHQmLmRpc2FibGVkIGEge1xyXG5cdFx0XHRcdFx0Y29sb3I6cmdiYSgwLCAwLCAwLCAwLjI2KSAhaW1wb3J0YW50O1xyXG5cdFx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdCYuYWN0aXZlIGEge1xyXG5cdFx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSgxNTgsMTU4LDE1OCwwLjIpO1xyXG5cdFx0XHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRhIHtcclxuXHRcdFx0XHRoZWlnaHQ6IDIycHg7XHJcblx0XHRcdFx0bWluLXdpZHRoOiAyNHB4O1xyXG5cdFx0XHRcdGxpbmUtaGVpZ2h0OiAyMnB4O1xyXG5cdFx0XHRcdHBhZGRpbmc6IDAgNnB4O1xyXG5cdFx0XHRcdGJvcmRlci1yYWRpdXM6IDNweDtcclxuXHRcdFx0XHRtYXJnaW46IDZweCAzcHg7XHJcblx0XHRcdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0XHRcdHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcblx0XHRcdFx0Y29sb3I6IHJnYmEoMCwwLDAsLjU0KTtcclxuXHRcdFx0XHR0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcblx0XHQgICAgdmVydGljYWwtYWxpZ246IGJvdHRvbTtcclxuXHJcblx0XHRcdFx0Jjpob3ZlciB7XHJcblx0XHRcdFx0XHRjb2xvcjogcmdiYSgwLDAsMCwuNzUpO1xyXG5cdFx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSgxNTgsMTU4LDE1OCwwLjIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LmRhdGF0YWJsZS1pY29uLWxlZnQsXHJcblx0XHRcdC5kYXRhdGFibGUtaWNvbi1za2lwLFxyXG5cdFx0XHQuZGF0YXRhYmxlLWljb24tcmlnaHQsXHJcblx0XHRcdC5kYXRhdGFibGUtaWNvbi1wcmV2e1xyXG5cdFx0XHRcdGZvbnQtc2l6ZToyMHB4O1xyXG5cdFx0XHRcdGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG5cdFx0XHRcdHBhZGRpbmc6MCAzcHg7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDaGVja2JveGVzXHJcbioqL1xyXG4uZGF0YXRhYmxlLWNoZWNrYm94IHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gIHBhZGRpbmc6IDA7XHJcblxyXG4gIGlucHV0W3R5cGU9J2NoZWNrYm94J10ge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbWFyZ2luOiAwIDFyZW0gMCAwO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgb3V0bGluZTpub25lO1xyXG5cclxuICAgICY6YmVmb3JlIHtcclxuICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcclxuICAgICAgLW1vei10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcclxuICAgICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgbGVmdDogMDtcclxuICAgICAgei1pbmRleDogMTtcclxuICAgICAgd2lkdGg6IDFyZW07XHJcbiAgICAgIGhlaWdodDogMXJlbTtcclxuICAgICAgYm9yZGVyOiAycHggc29saWQgI2YyZjJmMjtcclxuICAgIH1cclxuXHJcbiAgICAmOmNoZWNrZWQ6YmVmb3JlIHtcclxuICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgtNDVkZWcpO1xyXG4gICAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKC00NWRlZyk7XHJcbiAgICAgIC1tcy10cmFuc2Zvcm06IHJvdGF0ZSgtNDVkZWcpO1xyXG4gICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtNDVkZWcpO1xyXG4gICAgICBoZWlnaHQ6IC41cmVtO1xyXG4gICAgICBib3JkZXItY29sb3I6ICMwMDk2ODg7XHJcbiAgICAgIGJvcmRlci10b3Atc3R5bGU6IG5vbmU7XHJcbiAgICAgIGJvcmRlci1yaWdodC1zdHlsZTogbm9uZTtcclxuICAgIH1cclxuXHJcbiAgICAmOmFmdGVyIHtcclxuICAgICAgY29udGVudDogXCJcIjtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICB0b3A6IDA7XHJcbiAgICAgIGxlZnQ6IDA7XHJcbiAgICAgIHdpZHRoOiAxcmVtO1xyXG4gICAgICBoZWlnaHQ6IDFyZW07XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQcm9ncmVzcyBiYXIgYW5pbWF0aW9uc1xyXG4gKi9cclxuQGtleWZyYW1lcyBxdWVyeSB7XHJcbiAgMCUge1xyXG4gICAgb3BhY2l0eTogMTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgzNSUpIHNjYWxlKC4zLCAxKTsgXHJcbiAgfVxyXG5cclxuICAxMDAlIHtcclxuICAgIG9wYWNpdHk6IDA7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSkgc2NhbGUoMCwgMSk7IFxyXG4gIH0gXHJcbn1cclxuXHJcbi5kYXRhdGFibGUtcm93LWV2ZW5cclxue1xyXG5iYWNrZ3JvdW5kOiB3aGl0ZTtcclxufVxyXG4uZGF0YXRhYmxlLXJvdy1vZGRcclxue1xyXG5cdGJhY2tncm91bmQtY29sb3I6d2hpdGU7XHJcbn1cclxuIl19 */", ".divdisabled {\r\n    pointer-events: none;\r\n    opacity: 0.4;\r\n  }\r\n  \r\n  \r\n  .mat-option {\r\n  /* font-family: Roboto,\"Helvetica Neue\",sans-serif; */\r\n  font-size: 12px !important ;\r\n  line-height: 28px!important;\r\n    height: 28px!important;\r\n  }\r\n  \r\n  \r\n  .mat-form-field{\r\n  font-family:Roboto,\"Helvetica Neue\",sans-serif;\r\n  font-size:inherit;\r\n  font-weight:400;\r\n  line-height:1.125\r\n  }\r\n  \r\n  \r\n  .mat-form-field-wrapper{\r\n  padding-bottom:1.25em\r\n  }\r\n  \r\n  \r\n  .mat-form-field-prefix .mat-icon,.mat-form-field-suffix .mat-icon{\r\n  font-size:150%;\r\n  line-height:1.125\r\n  }\r\n  \r\n  \r\n  .mat-form-field-prefix .mat-icon-button,.mat-form-field-suffix .mat-icon-button{\r\n  height:1.5em;\r\n  width:1.5em\r\n  }\r\n  \r\n  \r\n  .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field-suffix .mat-icon-button .mat-icon{\r\n  height:1.125em;\r\n  line-height:1.125\r\n  }\r\n  \r\n  \r\n  .mat-form-field-infix{\r\n  padding:.4375em 0;\r\n  border-top:.84375em solid transparent;\r\n  width: 100% !important;\r\n  }\r\n  \r\n  \r\n  .mat-form-field-can-float.mat-form-field-should-float .mat-form-field-placeholder{\r\n  transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.001px);\r\n  -ms-transform:translateY(-1.28125em) scale(.75);\r\n  width:133.33333%\r\n  }\r\n  \r\n  \r\n  .mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-placeholder-wrapper .mat-form-field-placeholder{\r\n  transform:translateY(-1.28125em) scale(.75) perspective(100px) translateZ(.001px);\r\n  -ms-transform:translateY(-1.28125em) scale(.75);\r\n  width:133.33333%\r\n  }\r\n  \r\n  \r\n  .mat-form-field-placeholder-wrapper{\r\n  top:-.84375em;\r\n  padding-top:.84375em\r\n  }\r\n  \r\n  \r\n  .mat-form-field-placeholder{\r\n  top:1.28125em\r\n  }\r\n  \r\n  \r\n  .mat-form-field-underline{\r\n  bottom:1.25em\r\n  }\r\n  \r\n  \r\n  .mat-form-field-subscript-wrapper{\r\n  font-size:75%;\r\n  margin-top:.54167em;\r\n  top:calc(100% - 1.66667em)\r\n  }\r\n  \r\n  \r\n  input.mat-input-element\r\n  {\r\n  border: 0px !important;\r\n  }\r\n  \r\n  \r\n  .mat-autocomplete-panel\r\n  {\r\n  padding-left: 10px;\r\n  white-space: nowrap;\r\n  }\r\n  \r\n  \r\n  .mat-select-content, .mat-select-panel-done-animating\r\n  {\r\n  padding-left: 10px;\r\n  white-space: nowrap;\r\n  }\r\n  \r\n  \r\n  input.mat-input-element\r\n  {\r\n  padding-top: 5px ;\r\n  }\r\n  \r\n  \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hc3NldHMvc2Nzcy9uZ3gtZGF0YXRhYmxlLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLG9CQUFvQjtJQUNwQixZQUFZO0VBQ2Q7OztFQUdBO0VBQ0EscURBQXFEO0VBQ3JELDJCQUEyQjtFQUMzQiwyQkFBMkI7SUFDekIsc0JBQXNCO0VBQ3hCOzs7RUFFQTtFQUNBLDhDQUE4QztFQUM5QyxpQkFBaUI7RUFDakIsZUFBZTtFQUNmO0VBQ0E7OztFQUNBO0VBQ0E7RUFDQTs7O0VBQ0E7RUFDQSxjQUFjO0VBQ2Q7RUFDQTs7O0VBQ0E7RUFDQSxZQUFZO0VBQ1o7RUFDQTs7O0VBQ0E7RUFDQSxjQUFjO0VBQ2Q7RUFDQTs7O0VBQ0E7RUFDQSxpQkFBaUI7RUFDakIscUNBQXFDO0VBQ3JDLHNCQUFzQjtFQUN0Qjs7O0VBQ0E7RUFDQSxpRkFBaUY7RUFDakYsK0NBQStDO0VBQy9DO0VBQ0E7OztFQUNBO0VBQ0EsaUZBQWlGO0VBQ2pGLCtDQUErQztFQUMvQztFQUNBOzs7RUFDQTtFQUNBLGFBQWE7RUFDYjtFQUNBOzs7RUFDQTtFQUNBO0VBQ0E7OztFQUNBO0VBQ0E7RUFDQTs7O0VBQ0E7RUFDQSxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CO0VBQ0E7OztFQUVBOztFQUVBLHNCQUFzQjtFQUN0Qjs7O0VBQ0E7O0VBRUEsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQjs7O0VBQ0E7O0VBRUEsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQjs7O0VBQ0E7O0VBRUEsaUJBQWlCO0VBQ2pCIiwiZmlsZSI6InNyYy9hc3NldHMvc2Nzcy9uZ3gtZGF0YXRhYmxlLmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kaXZkaXNhYmxlZCB7XHJcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxuICAgIG9wYWNpdHk6IDAuNDtcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgLm1hdC1vcHRpb24ge1xyXG4gIC8qIGZvbnQtZmFtaWx5OiBSb2JvdG8sXCJIZWx2ZXRpY2EgTmV1ZVwiLHNhbnMtc2VyaWY7ICovXHJcbiAgZm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQgO1xyXG4gIGxpbmUtaGVpZ2h0OiAyOHB4IWltcG9ydGFudDtcclxuICAgIGhlaWdodDogMjhweCFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5tYXQtZm9ybS1maWVsZHtcclxuICBmb250LWZhbWlseTpSb2JvdG8sXCJIZWx2ZXRpY2EgTmV1ZVwiLHNhbnMtc2VyaWY7XHJcbiAgZm9udC1zaXplOmluaGVyaXQ7XHJcbiAgZm9udC13ZWlnaHQ6NDAwO1xyXG4gIGxpbmUtaGVpZ2h0OjEuMTI1XHJcbiAgfVxyXG4gIC5tYXQtZm9ybS1maWVsZC13cmFwcGVye1xyXG4gIHBhZGRpbmctYm90dG9tOjEuMjVlbVxyXG4gIH1cclxuICAubWF0LWZvcm0tZmllbGQtcHJlZml4IC5tYXQtaWNvbiwubWF0LWZvcm0tZmllbGQtc3VmZml4IC5tYXQtaWNvbntcclxuICBmb250LXNpemU6MTUwJTtcclxuICBsaW5lLWhlaWdodDoxLjEyNVxyXG4gIH1cclxuICAubWF0LWZvcm0tZmllbGQtcHJlZml4IC5tYXQtaWNvbi1idXR0b24sLm1hdC1mb3JtLWZpZWxkLXN1ZmZpeCAubWF0LWljb24tYnV0dG9ue1xyXG4gIGhlaWdodDoxLjVlbTtcclxuICB3aWR0aDoxLjVlbVxyXG4gIH1cclxuICAubWF0LWZvcm0tZmllbGQtcHJlZml4IC5tYXQtaWNvbi1idXR0b24gLm1hdC1pY29uLC5tYXQtZm9ybS1maWVsZC1zdWZmaXggLm1hdC1pY29uLWJ1dHRvbiAubWF0LWljb257XHJcbiAgaGVpZ2h0OjEuMTI1ZW07XHJcbiAgbGluZS1oZWlnaHQ6MS4xMjVcclxuICB9XHJcbiAgLm1hdC1mb3JtLWZpZWxkLWluZml4e1xyXG4gIHBhZGRpbmc6LjQzNzVlbSAwO1xyXG4gIGJvcmRlci10b3A6Ljg0Mzc1ZW0gc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICB9XHJcbiAgLm1hdC1mb3JtLWZpZWxkLWNhbi1mbG9hdC5tYXQtZm9ybS1maWVsZC1zaG91bGQtZmxvYXQgLm1hdC1mb3JtLWZpZWxkLXBsYWNlaG9sZGVye1xyXG4gIHRyYW5zZm9ybTp0cmFuc2xhdGVZKC0xLjI4MTI1ZW0pIHNjYWxlKC43NSkgcGVyc3BlY3RpdmUoMTAwcHgpIHRyYW5zbGF0ZVooLjAwMXB4KTtcclxuICAtbXMtdHJhbnNmb3JtOnRyYW5zbGF0ZVkoLTEuMjgxMjVlbSkgc2NhbGUoLjc1KTtcclxuICB3aWR0aDoxMzMuMzMzMzMlXHJcbiAgfVxyXG4gIC5tYXQtZm9ybS1maWVsZC1jYW4tZmxvYXQgLm1hdC1mb3JtLWZpZWxkLWF1dG9maWxsLWNvbnRyb2w6LXdlYmtpdC1hdXRvZmlsbCsubWF0LWZvcm0tZmllbGQtcGxhY2Vob2xkZXItd3JhcHBlciAubWF0LWZvcm0tZmllbGQtcGxhY2Vob2xkZXJ7XHJcbiAgdHJhbnNmb3JtOnRyYW5zbGF0ZVkoLTEuMjgxMjVlbSkgc2NhbGUoLjc1KSBwZXJzcGVjdGl2ZSgxMDBweCkgdHJhbnNsYXRlWiguMDAxcHgpO1xyXG4gIC1tcy10cmFuc2Zvcm06dHJhbnNsYXRlWSgtMS4yODEyNWVtKSBzY2FsZSguNzUpO1xyXG4gIHdpZHRoOjEzMy4zMzMzMyVcclxuICB9XHJcbiAgLm1hdC1mb3JtLWZpZWxkLXBsYWNlaG9sZGVyLXdyYXBwZXJ7XHJcbiAgdG9wOi0uODQzNzVlbTtcclxuICBwYWRkaW5nLXRvcDouODQzNzVlbVxyXG4gIH1cclxuICAubWF0LWZvcm0tZmllbGQtcGxhY2Vob2xkZXJ7XHJcbiAgdG9wOjEuMjgxMjVlbVxyXG4gIH1cclxuICAubWF0LWZvcm0tZmllbGQtdW5kZXJsaW5le1xyXG4gIGJvdHRvbToxLjI1ZW1cclxuICB9XHJcbiAgLm1hdC1mb3JtLWZpZWxkLXN1YnNjcmlwdC13cmFwcGVye1xyXG4gIGZvbnQtc2l6ZTo3NSU7XHJcbiAgbWFyZ2luLXRvcDouNTQxNjdlbTtcclxuICB0b3A6Y2FsYygxMDAlIC0gMS42NjY2N2VtKVxyXG4gIH1cclxuICBcclxuICBpbnB1dC5tYXQtaW5wdXQtZWxlbWVudFxyXG4gIHtcclxuICBib3JkZXI6IDBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICAubWF0LWF1dG9jb21wbGV0ZS1wYW5lbFxyXG4gIHtcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICB9XHJcbiAgLm1hdC1zZWxlY3QtY29udGVudCwgLm1hdC1zZWxlY3QtcGFuZWwtZG9uZS1hbmltYXRpbmdcclxuICB7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgfVxyXG4gIGlucHV0Lm1hdC1pbnB1dC1lbGVtZW50XHJcbiAge1xyXG4gIHBhZGRpbmctdG9wOiA1cHggO1xyXG4gIH1cclxuICBcclxuICAiXX0= */", ".cstmtbl tr th {\r\n    padding: 10px !important;\r\n    background: #f5f5f5;\r\n    font-size: .8rem;\r\n}\r\n.cstmtbl tr td {\r\n    padding: 10px !important;\r\n    /* background: #f5f5f5; */\r\n    font-size: .8rem;\r\n}\r\n.font8 \r\n{\r\n    font-size: .8rem;\r\n}\r\n.wid10\r\n{\r\n    width: 10%;\r\n}\r\n.mttop-3\r\n{\r\n    margin-top: -3px;\r\n}\r\n@media screen and (max-width:991px)\r\n{\r\n    .mobilenone\r\n    {\r\n        display: none;\r\n    }\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnNldHVwL21hbmFnZS1yb2xlL21hbmFnZS1yb2xlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx3QkFBd0I7SUFDeEIsbUJBQW1CO0lBQ25CLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksd0JBQXdCO0lBQ3hCLHlCQUF5QjtJQUN6QixnQkFBZ0I7QUFDcEI7QUFDQTs7SUFFSSxnQkFBZ0I7QUFDcEI7QUFDQTs7SUFFSSxVQUFVO0FBQ2Q7QUFDQTs7SUFFSSxnQkFBZ0I7QUFDcEI7QUFDQTs7SUFFSTs7UUFFSSxhQUFhO0lBQ2pCO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC91c2Vyc2V0dXAvbWFuYWdlLXJvbGUvbWFuYWdlLXJvbGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jc3RtdGJsIHRyIHRoIHtcclxuICAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6ICNmNWY1ZjU7XHJcbiAgICBmb250LXNpemU6IC44cmVtO1xyXG59XHJcbi5jc3RtdGJsIHRyIHRkIHtcclxuICAgIHBhZGRpbmc6IDEwcHggIWltcG9ydGFudDtcclxuICAgIC8qIGJhY2tncm91bmQ6ICNmNWY1ZjU7ICovXHJcbiAgICBmb250LXNpemU6IC44cmVtO1xyXG59XHJcbi5mb250OCBcclxue1xyXG4gICAgZm9udC1zaXplOiAuOHJlbTtcclxufVxyXG4ud2lkMTBcclxue1xyXG4gICAgd2lkdGg6IDEwJTtcclxufVxyXG4ubXR0b3AtM1xyXG57XHJcbiAgICBtYXJnaW4tdG9wOiAtM3B4O1xyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6OTkxcHgpXHJcbntcclxuICAgIC5tb2JpbGVub25lXHJcbiAgICB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxufSJdfQ== */"], encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ManageRoleComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-manage-role',
                templateUrl: './manage-role.component.html',
                styleUrls: [
                    // '../../../node_modules/primeicons/primeicons.css',
                    '../../../assets/scss/ngxdatatable.component.scss',
                    '../../../assets/scss/material.scss',
                    '../../../assets/scss/ngx-datatable.css',
                    './manage-role.component.css'
                ],
                encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewEncapsulation"].None
            }]
    }], function () { return [{ type: _services_form_service__WEBPACK_IMPORTED_MODULE_2__["FormService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/manage-userprofile/manage-userprofile.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/usersetup/manage-userprofile/manage-userprofile.component.ts ***!
  \******************************************************************************/
/*! exports provided: ManageUserprofileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageUserprofileComponent", function() { return ManageUserprofileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");




class ManageUserprofileComponent {
    constructor() { }
    ngOnInit() {
    }
}
ManageUserprofileComponent.ɵfac = function ManageUserprofileComponent_Factory(t) { return new (t || ManageUserprofileComponent)(); };
ManageUserprofileComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ManageUserprofileComponent, selectors: [["app-manage-userprofile"]], decls: 113, vars: 0, consts: [[1, "container-fluid", "mb-2"], [1, "col-sm-12", "p-0"], [1, "row"], [1, "col-sm-12"], [1, "font600", "mt-2", "tabsty", "bg_border", "pull-left"], [1, "card", "remove-shadow", "mb-1"], [1, "card-header", "font8"], [1, "card-body", "p-0", "mt-2"], [1, "row", "m-2"], [1, "col-sm-2"], [1, "col-sm-4"], [1, "form-control"], ["value", "--Select--"], ["type", "checkbox", 1, "mt-1"], [1, "row", "my-3"], [1, "col-sm-12", "text-center"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-plus"], ["href", "javascript:void(0)", 1, "btn", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-refresh"], [1, "card-body", "nopadding"], [1, "col-sm-12", "nopadding"], [1, "table", "table-bordered", "cstmtbl", "mb-0"], [1, "text-center"], ["href", "javascript:void(0)", 1, "btn-dark", "btn", "btn-sm"], [1, "fa", "fa-trash"]], template: function ManageUserprofileComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-new");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Manage User");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "User Details Profile");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "Activity");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "--Select--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "--Select--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "User Id");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "--Select User Id--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "Department");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "--Select Department--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Offices");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](49, "--Select Offices--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "Default Offices");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "--Select Default Offices--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, "All Users");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](62, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "a", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](66, "i", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](67, " Assign Role ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "a", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](69, "i", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](70, " Reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74, "User List");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "table", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "th", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](80, " Sr No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](82, "Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](84, "User Name / Email");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](85, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](86, "Mobile Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](88, "Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](90, "Offices");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](92, "Department");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "th", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](94, "Action");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "td", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](97, " 1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, " Raj Kumar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](101, "deo-pi12");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](103, "9965852365");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](105, "Master");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](107, "abc123");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](109, "abc");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "td", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "a", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](112, "i", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__["HeaderNewComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"]], styles: [".cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    background: #f5f5f5;\r\n    font-size: .8rem;\r\n}\r\n.cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    \r\n    font-size: .8rem;\r\n}\r\n.font8[_ngcontent-%COMP%] \r\n{\r\n    font-size: .8rem;\r\n}\r\n.mttop-3[_ngcontent-%COMP%]\r\n{\r\n    margin-top: -3px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnNldHVwL21hbmFnZS11c2VycHJvZmlsZS9tYW5hZ2UtdXNlcnByb2ZpbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSx3QkFBd0I7SUFDeEIseUJBQXlCO0lBQ3pCLGdCQUFnQjtBQUNwQjtBQUNBOztJQUVJLGdCQUFnQjtBQUNwQjtBQUNBOztJQUVJLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJzcmMvYXBwL3VzZXJzZXR1cC9tYW5hZ2UtdXNlcnByb2ZpbGUvbWFuYWdlLXVzZXJwcm9maWxlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3N0bXRibCB0ciB0aCB7XHJcbiAgICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xyXG4gICAgZm9udC1zaXplOiAuOHJlbTtcclxufVxyXG4uY3N0bXRibCB0ciB0ZCB7XHJcbiAgICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAvKiBiYWNrZ3JvdW5kOiAjZjVmNWY1OyAqL1xyXG4gICAgZm9udC1zaXplOiAuOHJlbTtcclxufVxyXG4uZm9udDggXHJcbntcclxuICAgIGZvbnQtc2l6ZTogLjhyZW07XHJcbn1cclxuLm10dG9wLTNcclxue1xyXG4gICAgbWFyZ2luLXRvcDogLTNweDtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ManageUserprofileComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-manage-userprofile',
                templateUrl: './manage-userprofile.component.html',
                styleUrls: ['./manage-userprofile.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/manage-users/manage-users.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/usersetup/manage-users/manage-users.component.ts ***!
  \******************************************************************/
/*! exports provided: ManageUsersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManageUsersComponent", function() { return ManageUsersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");




class ManageUsersComponent {
    constructor() { }
    ngOnInit() {
        $("#hideform").hide();
    }
    addform() {
        $("#hideform").show();
    }
    closeform() {
        $("#hideform").hide();
    }
}
ManageUsersComponent.ɵfac = function ManageUsersComponent_Factory(t) { return new (t || ManageUsersComponent)(); };
ManageUsersComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ManageUsersComponent, selectors: [["app-manage-users"]], decls: 173, vars: 0, consts: [[1, "container-fluid", "mb-2"], [1, "col-sm-12", "p-0"], [1, "row"], [1, "col-sm-12"], [1, "font600", "mt-2", "tabsty", "bg_border", "pull-left"], [1, "example-header", "cstmpage", "pt-0", "cstmflxs", "pull-left", "mt-2"], [1, "mr-1"], ["id", "page-size", 1, "cstmselect"], ["value", "10", "selected", ""], ["value", "100"], ["value", "500"], ["value", "1000"], ["href", "javascript:void(0)", 1, "btn", "btn-sm", "btn-white-dark", "filtericon", "pt-0", "pb-0", "hyt24"], [1, "fa", "fa-filter"], ["href", "javascript:void(0)", 1, "btn", "pull-right", "mt-2", "btn-dark", "rounded-pill", "px-3", "btn-sm", 3, "click"], [1, "mt-0", "mb-0"], [1, "card", "remove-shadow", "mb-1"], [1, "card-body", "nopadding"], [1, "col-sm-12", "nopadding"], [1, "table", "table-bordered", "cstmtbl", "mb-0"], [1, "text-center"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm"], [1, "fa", "fa-edit"], ["id", "hideform", 1, "card", "remove-shadow", "mb-1"], [1, "card-header", "font8"], [1, "card-body", "p-0", "mt-2"], [1, "row", "m-2"], [1, "col-sm-2"], [1, "col-sm-4"], [1, "form-control"], ["type", "text", "placeholder", "First Name", 1, "form-control"], ["type", "text", "placeholder", "Middle Name", 1, "form-control"], ["type", "text", "placeholder", "Last Name", 1, "form-control"], ["type", "text", "placeholder", "User Name", 1, "form-control"], ["value", "--Select--"], ["type", "text", "placeholder", "Pan Number", 1, "form-control"], ["type", "date", "placeholder", "mm/dd/yyyy", 1, "form-control"], ["type", "text", "placeholder", "Email ID", 1, "form-control"], ["type", "text", "placeholder", "Mobile Number", 1, "form-control"], ["type", "text", "placeholder", "Official Landline Number", 1, "form-control"], ["type", "text", "placeholder", "Official Email ID", 1, "form-control"], [1, "font600", "font8", "px-2"], [1, "mt-1", "mb-2"], ["placeholder", "Address Line 1", 1, "form-control2"], ["placeholder", "Address Line 2", 1, "form-control2"], [1, "row", "my-3"], [1, "col-sm-12", "text-center"], ["href", "javascript:void(0)", 1, "btn", "btn-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-save"], ["href", "javascript:void(0)", 1, "btn", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2"], [1, "fa", "fa-refresh"], ["href", "javascript:void(0)", 1, "btn", "btn-white-dark", "btn-sm", "px-3", "rounded-pill", "mr-2", 3, "click"], [1, "fa", "fa-times"]], template: function ManageUsersComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-new");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Manage User");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Page Size:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "select", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "10");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "50");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "option", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "100");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "500");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "option", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "1000");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "\u00A0\u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "a", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](23, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "a", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageUsersComponent_Template_a_click_24_listener() { return ctx.addform(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, " Add New User ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](26, "hr", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "table", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "th", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, " Sr No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](36, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](37, "User Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "Email ID");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Effective From Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "Mobile Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "th", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Action");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "td", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, " 1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50, " Raj Kumar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52, "102546");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](53, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](54, "rajkumar@gmail.com");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "04/20/2021");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](58, "9965852365");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "td", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "a", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](61, "i", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](65, "User Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](70, "Prefix");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "select", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74, "--Select--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](77, "First Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](79, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](81, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, "Middle Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](85, "input", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](88, "Last Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](90, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](94, "User Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](96, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](98, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](99, "Gender");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](100, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "select", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "option", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](103, "--Select--");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](107, "Pan Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](109, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112, "Date of Birth");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](114, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](115, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](118, "Email ID");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](119, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](120, "input", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](121, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](123, "Mobile Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](125, "input", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](129, "Effective From Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](131, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](133, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](134, "Effective Till Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](136, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](138, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](140, "Official Landline Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](142, "input", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](144, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](145, "Official Email ID");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](146, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](147, "input", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "h6", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](149, " Address Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](150, "hr", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](154, "Address Line 1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](155, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](156, "textarea", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](159, "Address Line 2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](161, "textarea", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "div", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](163, "div", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](164, "a", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](165, "i", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](166, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](167, "a", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](168, "i", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](169, " Reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](170, "a", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ManageUsersComponent_Template_a_click_170_listener() { return ctx.closeform(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](171, "i", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](172, " Close Form ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_1__["HeaderNewComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵangular_packages_forms_forms_x"]], styles: [".cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    background: #f5f5f5;\r\n    font-size: .8rem;\r\n}\r\n.cstmtbl[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n    padding: 10px !important;\r\n    \r\n    font-size: .8rem;\r\n}\r\n.font8[_ngcontent-%COMP%] \r\n{\r\n    font-size: .8rem;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnNldHVwL21hbmFnZS11c2Vycy9tYW5hZ2UtdXNlcnMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSx3QkFBd0I7SUFDeEIseUJBQXlCO0lBQ3pCLGdCQUFnQjtBQUNwQjtBQUNBOztJQUVJLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJzcmMvYXBwL3VzZXJzZXR1cC9tYW5hZ2UtdXNlcnMvbWFuYWdlLXVzZXJzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3N0bXRibCB0ciB0aCB7XHJcbiAgICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xyXG4gICAgZm9udC1zaXplOiAuOHJlbTtcclxufVxyXG4uY3N0bXRibCB0ciB0ZCB7XHJcbiAgICBwYWRkaW5nOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAvKiBiYWNrZ3JvdW5kOiAjZjVmNWY1OyAqL1xyXG4gICAgZm9udC1zaXplOiAuOHJlbTtcclxufVxyXG4uZm9udDggXHJcbntcclxuICAgIGZvbnQtc2l6ZTogLjhyZW07XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ManageUsersComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-manage-users',
                templateUrl: './manage-users.component.html',
                styleUrls: ['./manage-users.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/usersetup/usersetup-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/usersetup/usersetup-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: UsersetupRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersetupRoutingModule", function() { return UsersetupRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _manage_role_manage_role_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./manage-role/manage-role.component */ "./src/app/usersetup/manage-role/manage-role.component.ts");
/* harmony import */ var _manage_userprofile_manage_userprofile_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manage-userprofile/manage-userprofile.component */ "./src/app/usersetup/manage-userprofile/manage-userprofile.component.ts");
/* harmony import */ var _manage_users_manage_users_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./manage-users/manage-users.component */ "./src/app/usersetup/manage-users/manage-users.component.ts");
/* harmony import */ var _manage_menu_manage_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./manage-menu/manage-menu.component */ "./src/app/usersetup/manage-menu/manage-menu.component.ts");
/* harmony import */ var _manage_resource_manage_resource_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./manage-resource/manage-resource.component */ "./src/app/usersetup/manage-resource/manage-resource.component.ts");
/* harmony import */ var _assign_menu_role_assign_menu_role_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./assign-menu-role/assign-menu-role.component */ "./src/app/usersetup/assign-menu-role/assign-menu-role.component.ts");










const routes = [
    { path: '', component: _manage_users_manage_users_component__WEBPACK_IMPORTED_MODULE_4__["ManageUsersComponent"] },
    { path: 'userprofile', component: _manage_userprofile_manage_userprofile_component__WEBPACK_IMPORTED_MODULE_3__["ManageUserprofileComponent"] },
    { path: 'managerole', component: _manage_role_manage_role_component__WEBPACK_IMPORTED_MODULE_2__["ManageRoleComponent"] },
    { path: 'manageuser', component: _manage_users_manage_users_component__WEBPACK_IMPORTED_MODULE_4__["ManageUsersComponent"] },
    { path: 'managemenu', component: _manage_menu_manage_menu_component__WEBPACK_IMPORTED_MODULE_5__["ManageMenuComponent"] },
    { path: 'manageresource', component: _manage_resource_manage_resource_component__WEBPACK_IMPORTED_MODULE_6__["ManageResourceComponent"] },
    { path: 'assignmenurole', component: _assign_menu_role_assign_menu_role_component__WEBPACK_IMPORTED_MODULE_7__["AssignMenuRoleComponent"] }
];
class UsersetupRoutingModule {
}
UsersetupRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: UsersetupRoutingModule });
UsersetupRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function UsersetupRoutingModule_Factory(t) { return new (t || UsersetupRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](UsersetupRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UsersetupRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/usersetup/usersetup.module.ts":
/*!***********************************************!*\
  !*** ./src/app/usersetup/usersetup.module.ts ***!
  \***********************************************/
/*! exports provided: UsersetupModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersetupModule", function() { return UsersetupModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _usersetup_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./usersetup-routing.module */ "./src/app/usersetup/usersetup-routing.module.ts");
/* harmony import */ var _manage_role_manage_role_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./manage-role/manage-role.component */ "./src/app/usersetup/manage-role/manage-role.component.ts");
/* harmony import */ var _manage_users_manage_users_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./manage-users/manage-users.component */ "./src/app/usersetup/manage-users/manage-users.component.ts");
/* harmony import */ var _manage_userprofile_manage_userprofile_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./manage-userprofile/manage-userprofile.component */ "./src/app/usersetup/manage-userprofile/manage-userprofile.component.ts");
/* harmony import */ var _manage_menu_manage_menu_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./manage-menu/manage-menu.component */ "./src/app/usersetup/manage-menu/manage-menu.component.ts");
/* harmony import */ var _manage_resource_manage_resource_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./manage-resource/manage-resource.component */ "./src/app/usersetup/manage-resource/manage-resource.component.ts");
/* harmony import */ var _assign_menu_role_assign_menu_role_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./assign-menu-role/assign-menu-role.component */ "./src/app/usersetup/assign-menu-role/assign-menu-role.component.ts");
/* harmony import */ var _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../shared/header-new/header-new.component */ "./src/app/shared/header-new/header-new.component.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/__ivy_ngcc__/fesm2015/swimlane-ngx-datatable.js");













class UsersetupModule {
}
UsersetupModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: UsersetupModule });
UsersetupModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function UsersetupModule_Factory(t) { return new (t || UsersetupModule)(); }, imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _usersetup_routing_module__WEBPACK_IMPORTED_MODULE_3__["UsersetupRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_11__["NgxDatatableModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](UsersetupModule, { declarations: [_manage_role_manage_role_component__WEBPACK_IMPORTED_MODULE_4__["ManageRoleComponent"], _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_10__["HeaderNewComponent"], _manage_users_manage_users_component__WEBPACK_IMPORTED_MODULE_5__["ManageUsersComponent"], _manage_userprofile_manage_userprofile_component__WEBPACK_IMPORTED_MODULE_6__["ManageUserprofileComponent"], _manage_menu_manage_menu_component__WEBPACK_IMPORTED_MODULE_7__["ManageMenuComponent"], _manage_resource_manage_resource_component__WEBPACK_IMPORTED_MODULE_8__["ManageResourceComponent"], _assign_menu_role_assign_menu_role_component__WEBPACK_IMPORTED_MODULE_9__["AssignMenuRoleComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
        _usersetup_routing_module__WEBPACK_IMPORTED_MODULE_3__["UsersetupRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
        _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_11__["NgxDatatableModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](UsersetupModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [_manage_role_manage_role_component__WEBPACK_IMPORTED_MODULE_4__["ManageRoleComponent"], _shared_header_new_header_new_component__WEBPACK_IMPORTED_MODULE_10__["HeaderNewComponent"], _manage_users_manage_users_component__WEBPACK_IMPORTED_MODULE_5__["ManageUsersComponent"], _manage_userprofile_manage_userprofile_component__WEBPACK_IMPORTED_MODULE_6__["ManageUserprofileComponent"], _manage_menu_manage_menu_component__WEBPACK_IMPORTED_MODULE_7__["ManageMenuComponent"], _manage_resource_manage_resource_component__WEBPACK_IMPORTED_MODULE_8__["ManageResourceComponent"], _assign_menu_role_assign_menu_role_component__WEBPACK_IMPORTED_MODULE_9__["AssignMenuRoleComponent"]],
                imports: [
                    _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                    _usersetup_routing_module__WEBPACK_IMPORTED_MODULE_3__["UsersetupRoutingModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                    _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_11__["NgxDatatableModule"]
                ]
            }]
    }], null, null); })();


/***/ })

}]);
//# sourceMappingURL=usersetup-usersetup-module.js.map